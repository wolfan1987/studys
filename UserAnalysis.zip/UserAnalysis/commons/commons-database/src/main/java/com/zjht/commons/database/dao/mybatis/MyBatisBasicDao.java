package com.zjht.commons.database.dao.mybatis;

import com.zjht.commons.database.dao.BasicDao;

import java.io.Serializable;
import java.lang.reflect.Method;

/**
 * Created by leaves chen<leaves615@gmail.com> on 16/3/30.
 *
 * @Author leaves chen<leaves615@gmail.com>
 */
public abstract class MyBatisBasicDao<T> extends BasicDao<T> {


}
