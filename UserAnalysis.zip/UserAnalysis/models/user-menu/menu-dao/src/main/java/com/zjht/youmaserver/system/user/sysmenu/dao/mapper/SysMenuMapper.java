package com.zjht.youmaserver.system.user.sysmenu.dao.mapper;

import java.util.List;

import com.zjht.youmaserver.system.user.sysmenu.entity.SysMenu;
import org.apache.ibatis.annotations.Param;



public interface SysMenuMapper {
	  int save(@Param("sysMenu") SysMenu sysMenu);
	  
	  void deleteSysMenuById(@Param("id")String id);
	  
	  SysMenu findById(@Param("id") String id);
	  
	  void updateSysMenu(@Param("sysMenu")SysMenu sysMenu);
	  
	  List<SysMenu> findSysMenuList();
	  
	  List<SysMenu> findByParentId(@Param("id") String id);
}
