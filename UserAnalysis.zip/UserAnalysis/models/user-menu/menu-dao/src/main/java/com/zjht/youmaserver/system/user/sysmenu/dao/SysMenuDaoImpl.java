package com.zjht.youmaserver.system.user.sysmenu.dao;

import java.util.List;

import com.zjht.youmaserver.system.user.sysmenu.entity.SysMenu;
import org.smarabbit.massy.annotation.ExportService;

import com.zjht.youmaserver.system.user.sysmenu.dao.mapper.SysMenuMapper;
import com.zjth.youmaserver.system.user.sysmenu.dao.SysMenuDao;
import com.zjth.youmaserver.system.user.sysmenu.dao.SysMenuWriteDao;

@ExportService(serviceTypes = {SysMenuWriteDao.class,SysMenuDao.class})
public class SysMenuDaoImpl implements SysMenuWriteDao{
	private SysMenuMapper sysMenuMapper;
	public SysMenuMapper getSysMenuMapper() {
		return sysMenuMapper;
	}
	public void setSysMenuMapper(SysMenuMapper sysMenuMapper) {
		this.sysMenuMapper = sysMenuMapper;
	}
	@Override
	public SysMenu findById(String id) {
		return sysMenuMapper.findById(id);
	}
	@Override
	public List<SysMenu> findSysMenuList(){
		return sysMenuMapper.findSysMenuList();
	}
	@Override
	public void deleteSysMenuById(String id){
		sysMenuMapper.deleteSysMenuById(id);
	}
	@Override
	public void updateSysMenu(SysMenu sysMenu){
		sysMenuMapper.updateSysMenu(sysMenu);
	}
	@Override
	public void saveSysMenu(SysMenu sysMenu){
		sysMenuMapper.save(sysMenu);
	}
	@Override
	public List<SysMenu> findChildSysMenuList(String id) {
		return sysMenuMapper.findByParentId(id);
	}
}
