package com.zjht.youmaserver.system.user.sysmenu.manager.ui;

import java.util.List;

import javax.validation.Valid;

import com.zjht.youmaserver.system.user.sysmenu.entity.SysMenu;
import org.apache.log4j.Logger;
import org.smarabbit.massy.annotation.ImportService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zjht.youmaserver.system.user.sysmenu.service.SysMenuService;
import com.zjth.youmaserver.system.user.sysmenu.dao.SysMenuDao;

@RequestMapping("/sys")
@Controller
public class SysMenuController {
	
	private Logger log = Logger.getLogger(this.getClass());
	
	@ImportService
	private SysMenuDao sysMenuDao;
	
	@ImportService
	private SysMenuService sysMenuService;
	
	@RequestMapping(value = "/system/menus", method = RequestMethod.GET)
	public String menu(ModelMap model){
		log.info("========>进入菜单列表");
		List<SysMenu> sysMenuList = sysMenuService.getSysMenuList();
		log.info("获取菜单列表========>"+sysMenuList);
		model.addAttribute(sysMenuList);
		return "sysmenu/sysmenu";
	}
	
	@RequestMapping("/system/del")
	public String deleteMenu(String id){
		if(id==null){
			log.info("=======>删除操作失败,参数不能为空!");
		}
		sysMenuService.deleteSysMenuById(id);	
		return "redirect:/sys/system/menus.html";
	}
	
	@RequestMapping(value = "/system/updateSave", method = RequestMethod.POST)
	public String updateSysMenu(@ModelAttribute("sysMenu") @Valid SysMenu sysMenu, ModelMap model){
		if(sysMenu==null){
			log.info("=======>保存操作失败,传入参数为空!");
		}
		sysMenuService.updateSysMenu(sysMenu);
		return "redirect:/sys/system/menus.html";
	}
	
	@RequestMapping("/system/modify")
	public String modifySysMenu(String id,ModelMap model){
		if(id==null){
			log.info("=======>获取菜单失败失败,菜单参数为空!");
			return "redirect:/sys/system/menus.html";
		}
		SysMenu sysMenu = sysMenuDao.findById(id);
		model.addAttribute("sysMenu",sysMenu);
		return "sysmenu/modifySysMenu";
	}
	@RequestMapping("/system/addSysMenu")
	public String addSysMenu(ModelMap model){
		log.info("======>获取父级菜单列表操作");
		List<SysMenu> sysMenuList = sysMenuService.getSysMenuList();
		model.addAttribute("sysMenuList",sysMenuList);
		log.info("======>产生列表"+sysMenuList);
		return "sysmenu/addSysMenu";
	}
	@RequestMapping(value = "/system/addSave", method = RequestMethod.POST)
	public String addSaveSysMenu(@ModelAttribute("sysMenu") @Valid SysMenu sysMenu, ModelMap model){
		if(sysMenu.getName()==null||"".equals(sysMenu.getName())){
			log.info("=======>保存操作失败,传入参数为空!");
			return "redirect:/sys/system/menus.html";
		}
		log.info("======>保存菜单操作!"+sysMenu);
		sysMenuService.createSysMenu(sysMenu);
		return "redirect:/sys/system/menus.html";
	}
	
	@RequestMapping("/system/addChildMenu")
	public String addChildMenu(ModelMap model,String id){
		if(id==null||"".equals(id)){
			log.info("=======>添加子菜单操作失败,传入参数为空!");
			return "redirect:/sys/system/menus.html";
		}
		model.addAttribute("id", id);
		return "sysmenu/addSysMenu";
	}
}
