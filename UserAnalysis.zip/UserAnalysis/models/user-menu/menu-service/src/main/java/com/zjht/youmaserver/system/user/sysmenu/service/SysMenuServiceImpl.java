package com.zjht.youmaserver.system.user.sysmenu.service;

import java.util.ArrayList;
import java.util.List;

import com.zjht.youmaserver.system.user.sysmenu.entity.SysMenu;
import org.smarabbit.massy.annotation.ExportService;
import org.smarabbit.massy.annotation.ImportService;

import com.zjth.youmaserver.system.user.sysmenu.dao.SysMenuWriteDao;

@ExportService(serviceTypes = {SysMenuService.class})
public class SysMenuServiceImpl implements SysMenuService{
	
	@ImportService
	private SysMenuWriteDao sysMenuWriteDao;

	@Override
	public void deleteSysMenuById(String id) {
		sysMenuWriteDao.deleteSysMenuById(id);
	}
	@Override
	public void updateSysMenu(SysMenu sysMenu) {
		sysMenuWriteDao.updateSysMenu(sysMenu);
	}
	@Override
	public void createSysMenu(SysMenu sysMenu) {
		if(sysMenu==null){
			return;
		}
		if(sysMenu.getName()!=null){
			sysMenu.setId(sysMenu.getName());
		}else{
			System.out.println("传入菜单名字为空");
			return;
		}
		sysMenuWriteDao.saveSysMenu(sysMenu);	
	}
	@Override
	public List<SysMenu> getSysMenuList() {
		List<SysMenu> list = new ArrayList<SysMenu>();
		List<SysMenu> newList = new ArrayList<SysMenu>();
		list = sysMenuWriteDao.findSysMenuList();
		for (int i = 0; i < list.size(); i++) {
			SysMenu sysMenu = list.get(i);
			sysMenu.setChildMenu(getChildMenuList(sysMenuWriteDao.findChildSysMenuList(sysMenu.getId())));
			newList.add(sysMenu);
		}
		return newList;
	}
	
	private List<SysMenu> getChildMenuList(List<SysMenu> sysMenuList){
		List<SysMenu> newList = new ArrayList<SysMenu>();
		for (int i = 0; i < sysMenuList.size(); i++) {
			SysMenu sysMenu = sysMenuList.get(i);
			List<SysMenu> list = sysMenuWriteDao.findChildSysMenuList(sysMenu.getId());
			if(!list.isEmpty()&&list!=null&&list.size()!=0){
				sysMenu.setChildMenu(getChildMenuList(list));
			}
			newList.add(sysMenu);
		}
		return newList;
	}
}
