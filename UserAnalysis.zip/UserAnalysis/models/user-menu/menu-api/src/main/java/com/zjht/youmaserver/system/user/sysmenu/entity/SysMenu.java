package com.zjht.youmaserver.system.user.sysmenu.entity;

import java.io.Serializable;
import java.util.List;

public class SysMenu implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3589805396906478023L;
	private String id;
	private String icon;
	private String name;
	private String label;
	private String href;
	private Long divided;
	private String superiorName;
	private String menuType;
	private Integer ordered;
	private List<SysMenu> childMenu;
	public List<SysMenu> getChildMenu() {
		return childMenu;
	}
	public void setChildMenu(List<SysMenu> childMenu) {
		this.childMenu = childMenu;
	}
	public SysMenu(){
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getHref() {
		return href;
	}
	public void setHref(String href) {
		this.href = href;
	}
	public Long getDivided() {
		return divided;
	}
	public void setDivided(Long divided) {
		this.divided = divided;
	}
	public String getSuperiorName() {
		return superiorName;
	}
	public void setSuperiorName(String superiorName) {
		this.superiorName = superiorName;
	}
	public String getMenuType() {
		return menuType;
	}
	public void setMenuType(String menuType) {
		this.menuType = menuType;
	}
	public Integer getOrdered() {
		return ordered;
	}
	public void setOrdered(Integer ordered) {
		this.ordered = ordered;
	}
	@Override
	public String toString() {
		return "SysMenu [id=" + id + ", icon=" + icon + ", name=" + name + ", label=" + label + ", href=" + href
				+ ", divided=" + divided + ", superiorName=" + superiorName + ", menuType=" + menuType + ", ordered="
				+ ordered + ", childMenu=" + childMenu + "]";
	}
	
}
