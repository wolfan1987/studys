package com.zjth.youmaserver.system.user.sysmenu.dao;

import com.zjht.youmaserver.system.user.sysmenu.entity.SysMenu;

import java.util.List;



public interface SysMenuDao {
	
	SysMenu findById(String id);
	
	List<SysMenu> findSysMenuList();
	
	List<SysMenu> findChildSysMenuList(String id);
}
