package com.zjth.youmaserver.system.user.sysmenu.dao;


import com.zjht.youmaserver.system.user.sysmenu.entity.SysMenu;

public interface SysMenuWriteDao extends SysMenuDao{
	public void deleteSysMenuById(String id);
	public void updateSysMenu(SysMenu menu);
	public void saveSysMenu(SysMenu sysMenu);
}
