package com.zjht.youmaserver.system.user.sysmenu.service;

import com.zjht.youmaserver.system.user.sysmenu.entity.SysMenu;

import java.util.List;



public interface SysMenuService {
	
	/**
	 * 保存菜单
	 * @param menu
	 */
	void createSysMenu(SysMenu sysMenu);
//	/**
//	 * 根据ID查找菜单
//	 * @param id
//	 * @return
//	 */
//	SysMenu findById(String id);
//	
	/**
	 * 获取菜单列表
	 * @return
	 */
	List<SysMenu> getSysMenuList();
	
	/**
	 * 根据菜单ID删除菜单
	 * @param id
	 */
	void deleteSysMenuById(String id);
	
	/**
	 * 更新菜单
	 * @param menu
	 */
	void updateSysMenu(SysMenu sysMenu);
}
