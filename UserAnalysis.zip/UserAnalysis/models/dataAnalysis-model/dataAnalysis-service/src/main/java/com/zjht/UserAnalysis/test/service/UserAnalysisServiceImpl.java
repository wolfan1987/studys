package com.zjht.UserAnalysis.test.service;

import org.smarabbit.massy.annotation.ExportService;
import org.smarabbit.massy.annotation.ImportService;
import org.springframework.transaction.annotation.Transactional;

import com.zjht.UserAnalysis.test.dao.UserAnalysisWriteDao;
import com.zjht.UserAnalysis.test.entity.Test;

/**
 * Created by leaves chen<leaves615@gmail.com> on 16/3/30.
 *
 * @Author leaves chen<leaves615@gmail.com>
 */

@ExportService(serviceTypes = {UserAnalysisService.class})
public class UserAnalysisServiceImpl implements UserAnalysisService {
    @ImportService
    private UserAnalysisWriteDao userAnalysisWriteDao;



    @Override
    @Transactional

    public void createTest(Test test) {
        userAnalysisWriteDao.save(test);
    }
}
