package com.zjht.UserAnalysis.test.manager.ui;

import com.zjht.UserAnalysis.Util.ResponseUtils;
import com.zjht.UserAnalysis.test.dao.UserAnalysisDao;
import com.zjht.UserAnalysis.test.entity.*;
import com.zjht.UserAnalysis.test.entity.Comsumption.AreaOrder;
import com.zjht.UserAnalysis.test.entity.Comsumption.GoodsSellCustomer;
import com.zjht.UserAnalysis.test.entity.Comsumption.UserBuyTimes;
import com.zjht.UserAnalysis.test.entity.Goods.GoodsSell;
import com.zjht.UserAnalysis.test.entity.Goods.KeyWord;
import com.zjht.UserAnalysis.test.entity.Goods.OrderCalc;
import com.zjht.UserAnalysis.test.entity.Online.OnlinePeriod;
import com.zjht.UserAnalysis.test.entity.Personas.AgeCalc;
import com.zjht.UserAnalysis.test.entity.Personas.SexCalc;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceOS;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceType;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceBrower;
import com.zjht.UserAnalysis.test.entity.UserAccerss.OriginCalc;
import com.zjht.UserAnalysis.test.entity.UserAccerss.VisitCalc;
import com.zjht.UserAnalysis.test.entity.UserAccerss.VisitPageCalc;
import com.zjht.UserAnalysis.test.entity.UserArea.AreaClient;
import com.zjht.UserAnalysis.test.entity.UserComprise.UserCompriseCalc;
import com.zjht.UserAnalysis.test.entity.UserComprise.UserCompriseCalcHour;
import com.zjht.UserAnalysis.test.entity.UserViscosity.HeightUserCalc;
import com.zjht.UserAnalysis.test.entity.UserViscosity.LightUserCalc;
import com.zjht.UserAnalysis.test.entity.UserViscosity.VitalityCalc;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.OriginCalcHour;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.VisitCalcHour;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.VisitPageCalcHour;
import com.zjht.UserAnalysis.test.service.UserAnalysisService;
import org.json.JSONObject;
import org.smarabbit.massy.annotation.ImportService;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by leaves chen<leaves615@gmail.com> on 16/3/30.
 *
 * @Author leaves chen<leaves615@gmail.com>
 */
@Controller
public class UserAnalysisController {
    @ImportService
    private UserAnalysisService userAnalysisService;
    @ImportService
    private UserAnalysisDao userAnalysisDao;

    //用户访问
    @RequestMapping("/UserAnalysis")
    public String UserAnalysis( ) {
        return "test/UserAnalysis";
    }

    @RequestMapping(value="/OriginCalcAjax",method = RequestMethod.POST)
    public void OriginCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<OriginCalc> OriginCalc = userAnalysisDao.findOriginCalc(siteid,source,selectTime);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("OriginCalcList",OriginCalc);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VisitCalcAjax",method = RequestMethod.POST)
    public void VisitCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String source= request.getParameter("source");
        String siteid= request.getParameter("siteid");
        //获取用户的组成信息
        List<VisitCalc> VisitCalc = userAnalysisDao.findVisitCalc(siteid,source,selectTime);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VisitCalcList",VisitCalc);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VisitPageCalcAjax",method = RequestMethod.POST)
    public void VisitPageCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String source= request.getParameter("source");
        String siteid= request.getParameter("siteid");
        //获取用户的组成信息
        List<VisitPageCalc> VisitPageCalc = userAnalysisDao.findVisitPageCalc(siteid,source,selectTime);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VisitPageCalcList",VisitPageCalc);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    //终端设备来源
    @RequestMapping(value="/OriginCalcSiteidAjax",method = RequestMethod.GET)
    public void OriginCalcSiteidAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> OriginCalcSiteid = userAnalysisDao.findOriginCalcSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("OriginCalcSiteid",OriginCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VisitCalcSiteidAjax",method = RequestMethod.GET)
    public void VisitCalcSiteidAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> VisitCalcSiteid = userAnalysisDao.findVisitCalcSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VisitCalcSiteid",VisitCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VisitPageCalcSiteidAjax",method = RequestMethod.GET)
    public void VisitPageCalcSiteidAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> VisitPageCalcSiteid = userAnalysisDao.findVisitPageCalcSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VisitPageCalcSiteid",VisitPageCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }




    //用户访问分时
    @RequestMapping("/UserAnalysisHour")
    public String UserAnalysisHour( ) {
        return "test/UserAnalysisHour";
    }

    @RequestMapping(value="/OriginCalcHourAjax",method = RequestMethod.POST)
    public void OriginCalcHourAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String hour= request.getParameter("hour");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<OriginCalcHour> OriginCalcHour = userAnalysisDao.findOriginCalcHour(siteid,source,selectTime,hour);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("OriginCalcHour",OriginCalcHour);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VisitCalcHourAjax",method = RequestMethod.POST)
    public void VisitCalcHourAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String hour= request.getParameter("hour");
        String source= request.getParameter("source");
        String siteid= request.getParameter("siteid");
        //获取用户的组成信息
        List<VisitCalcHour> VisitCalcHour = userAnalysisDao.findVisitCalcHour(siteid,source,selectTime,hour);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VisitCalcHour",VisitCalcHour);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VisitPageCalcHourAjax",method = RequestMethod.POST)
    public void VisitPageCalcHourAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String hour= request.getParameter("hour");
        String source= request.getParameter("source");
        String siteid= request.getParameter("siteid");
        //获取用户的组成信息
        List<VisitPageCalcHour> VisitPageCalcHour = userAnalysisDao.findVisitPageCalcHour(siteid,source,selectTime,hour);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VisitPageCalcHour",VisitPageCalcHour);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    //终端设备来源
    @RequestMapping(value="/OriginCalcSiteidHourAjax",method = RequestMethod.GET)
    public void OriginCalcSiteidHourAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> OriginCalcSiteid = userAnalysisDao.findOriginCalcHourSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("OriginCalcSiteid",OriginCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VisitCalcSiteidHourAjax",method = RequestMethod.GET)
    public void VisitCalcSiteidHourAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> VisitCalcSiteid = userAnalysisDao.findVisitCalcHourSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VisitCalcSiteid",VisitCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VisitPageCalcSiteidHourAjax",method = RequestMethod.GET)
    public void VisitPageCalcSiteidHourAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> VisitPageCalcSiteid = userAnalysisDao.findVisitPageCalcHourSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VisitPageCalcSiteid",VisitPageCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }








    //用户组成
    @RequestMapping("/UserComposition")
    public String StackChart() {
        return "test/UserComposition";
    }

    @RequestMapping(value="/UserCompositionAjax",method = RequestMethod.POST)
    public void StackChartAjax( HttpServletResponse response,HttpServletRequest request) {
        String startTime= request.getParameter("startTime");
        String endTime= request.getParameter("endTime");
        String source= request.getParameter("source");
        String siteid= request.getParameter("siteid");

        //获取用户的组成信息
         List<UserCompriseCalc> userCompriseCalcs = userAnalysisDao.findUserCompriseCalc(startTime,endTime,source,siteid);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userCompriseCalcs",userCompriseCalcs);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/UserCompositionSourceAjax",method = RequestMethod.GET)
    public void UserCompositionSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> UserSiteid = userAnalysisDao.findUserCompriseCalcSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("UserSiteid",UserSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }


    //用户组成分时
    @RequestMapping("/UserCompositionHour")
    public String UserCompositionHour() {
        return "test/UserCompositionHour";
    }

    @RequestMapping(value="/userCompriseCalcsHourAjax",method = RequestMethod.POST)
    public void userCompriseCalcsHourAjax( HttpServletResponse response,HttpServletRequest request) {

        String selectTime= request.getParameter("selectTime");
        String source= request.getParameter("source");
        String siteid= request.getParameter("siteid");
        //获取用户的组成信息
        List<UserCompriseCalcHour> userCompriseCalcsHour = userAnalysisDao.findUserCompriseCalcHour(selectTime,source,siteid);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userCompriseCalcsHour",userCompriseCalcsHour);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/userCompriseCalcsHourSourceAjax",method = RequestMethod.GET)
    public void userCompriseCalcsHourSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> UserSiteid = userAnalysisDao.findUserCompriseCalcHourSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("UserSiteid",UserSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }



    //终端设备
    @RequestMapping("/TerminalDevice")
    public String TerminalDevice() {
        return "test/TerminalDevice";
    }
    //终端设备数据
    @RequestMapping(value="/DeviceBrowserAjax",method = RequestMethod.POST)
    public void DeviceBrowserAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<DeviceBrower> deviceBrowser = userAnalysisDao.findDeviceBrowser(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("deviceBrowserList",deviceBrowser);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/DeviceOSAjax",method = RequestMethod.POST)
    public void DeviceOSAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<DeviceOS> deviceOS = userAnalysisDao.findDeviceOS(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("deviceOSList",deviceOS);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/DeviceTypeAjax",method = RequestMethod.POST)
    public void DeviceTypeAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<DeviceType> deviceType = userAnalysisDao.findDeviceType(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("deviceTypeList",deviceType);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    //终端设备来源
    @RequestMapping(value="/DeviceBrowserSourceAjax",method = RequestMethod.GET)
    public void DeviceBrowserSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> deviceBrowserSiteid = userAnalysisDao.findDeviceBrowserSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("deviceBrowserSiteid",deviceBrowserSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/DeviceOSSourceAjax",method = RequestMethod.GET)
    public void DeviceOSSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> deviceOSSiteid = userAnalysisDao.findDeviceOSSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("deviceOSSiteid",deviceOSSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/DeviceTypeSourceAjax",method = RequestMethod.GET)
    public void DeviceTypeSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> deviceTypeSiteid = userAnalysisDao.findDeviceTypeSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("deviceTypeSiteid",deviceTypeSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }

    //地区客户
    @RequestMapping("/AreaClient")
    public String AreaClient() {
        return "test/AreaClient";
    }
    @RequestMapping(value="/AreaClientAjax",method = RequestMethod.POST)
    public void AreaClientAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<AreaClient> AreaClientList = userAnalysisDao.findAreaClient(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("AreaClientList",AreaClientList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/AreaClientSourceAjax",method = RequestMethod.GET)
    public void AreaClientSourceAjax(HttpServletResponse response) {
        //获取用户的组成信息
        List<String> AreaClientSiteid = userAnalysisDao.findAreaClientSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("AreaClientSiteid",AreaClientSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }

    //商品分析
    @RequestMapping("/GoodsCalc")
    public String GoodsCalc() {
        return "test/GoodsCalc";
    }
       //商品销售
    @RequestMapping(value="/GoodsSellAjax",method = RequestMethod.POST)
    public void GoodsSellAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<GoodsSell> GoodsSell = userAnalysisDao.findGoodsSell(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("GoodsSellList",GoodsSell);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/GoodsSellSourceAjax",method = RequestMethod.GET)
    public void GoodsSellSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> GoodsSellSiteid = userAnalysisDao.findGoodsSellSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("GoodsSellSiteid",GoodsSellSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
       //搜索关键字
    @RequestMapping(value="/KeyWordAjax",method = RequestMethod.POST)
    public void KeyWordAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<KeyWord> KeyWord = userAnalysisDao.findKeyWord(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("KeyWordList",KeyWord);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/KeyWordSourceAjax",method = RequestMethod.GET)
    public void KeyWordSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> KeyWordSiteid = userAnalysisDao.findKeyWordSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("KeyWordSiteid",KeyWordSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
       //订单
    @RequestMapping(value="/OrderCalcAjax",method = RequestMethod.POST)
    public void OrderCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String startTime= request.getParameter("startTime");
        String endTime= request.getParameter("endTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<OrderCalc> OrderCalc = userAnalysisDao.findOrderCalc(startTime,endTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("OrderCalcList",OrderCalc);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/OrderCalcSourceAjax",method = RequestMethod.GET)
    public void OrderCalcSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> OrderCalcSiteid = userAnalysisDao.findOrderCalcSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("OrderCalcSiteid",OrderCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }

    //用户活跃度
    @RequestMapping("/UserVitality")
    public String UserVitality() {
        return "test/UserVitality";
    }
    @RequestMapping(value="/VitalityCalcAjax",method = RequestMethod.POST)
    public void VitalityCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String startTime= request.getParameter("startTime");
        String endTime= request.getParameter("endTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<VitalityCalc> VitalityCalc = userAnalysisDao.findVitalityCalc(startTime,endTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VitalityCalcList",VitalityCalc);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/VitalityCalcSourceAjax",method = RequestMethod.GET)
    public void VitalityCalcSourceAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> VitalityCalcSiteid = userAnalysisDao.findVitalityCalcSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("VitalityCalcSiteid",VitalityCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }



    //用户画像
    @RequestMapping("/Personas")
    public String Personas() {
        return "test/Personas";
    }
    @RequestMapping(value="/AgeCalcAjax",method = RequestMethod.POST)
    public void AgeCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<AgeCalc> AgeCalcList = userAnalysisDao.findAgeCalc(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("AgeCalcList",AgeCalcList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/AgeCalcSourceAjax",method = RequestMethod.GET)
    public void AgeCalcSourceAjax(HttpServletResponse response) {
        //获取用户的组成信息
        List<String> AgeCalcSiteid = userAnalysisDao.findAgeCalcSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("AgeCalcSiteid",AgeCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/SexCalcAjax",method = RequestMethod.POST)
    public void SexCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<SexCalc> SexCalcList = userAnalysisDao.findSexCalc(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("SexCalcList",SexCalcList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/SexCalcSourceAjax",method = RequestMethod.GET)
    public void SexCalcSourceAjax(HttpServletResponse response) {
        //获取用户的组成信息
        List<String> SexCalcSiteid = userAnalysisDao.findSexCalcSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("SexCalcSiteid",SexCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }

    //消费情况
    @RequestMapping("/Consumption")
    public String Consumption() {
        return "test/Consumption";
    }
     //地区订单
    @RequestMapping(value="/AreaOrderAjax",method = RequestMethod.POST)
    public void AreaOrderAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<AreaOrder> AreaOrderList = userAnalysisDao.findAreaOrder(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("AreaOrderList",AreaOrderList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/findAreaOrderByAreaSourceAjax",method = RequestMethod.POST)
    public void findAreaOrderByAreaSourceAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        String area= request.getParameter("area");
        //获取用户的组成信息
        List<AreaOrder> AreaOrderList = userAnalysisDao.findAreaOrderByAreaSource(selectTime,area,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("AreaOrderList",AreaOrderList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/AreaOrderSourceAjax",method = RequestMethod.GET)
    public void AreaOrderSourceAjax(HttpServletResponse response) {
        //获取用户的组成信息
        List<String> AreaOrderSource = userAnalysisDao.findAreaOrderSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("AreaOrderSource",AreaOrderSource);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/findAreaOrderAreaAjax",method = RequestMethod.POST)
    public void findAreaOrderAreaAjax( HttpServletResponse response,HttpServletRequest request) {
        String siteid= request.getParameter("siteid");
        //获取用户的组成信息
        List<String> areaList = userAnalysisDao.findAreaOrderArea(siteid);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("areaList",areaList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    //商品消费
    @RequestMapping(value="/GoodsSellCustomerAjax",method = RequestMethod.POST)
    public void GoodsSellCustomerAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<GoodsSellCustomer> GoodsSellCustomerList = userAnalysisDao.findGoodsSellCustomer(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("GoodsSellCustomerList",GoodsSellCustomerList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/GoodsSellCustomerSourceAjax",method = RequestMethod.GET)
    public void GoodsSellCustomerSourceAjax(HttpServletResponse response) {
        //获取用户的组成信息
        List<String> GoodsSellCustomerSource = userAnalysisDao.findGoodsSellCustomerSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("GoodsSellCustomerSource",GoodsSellCustomerSource);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    //用户消费
    @RequestMapping(value="/UserBuyTimesAjax",method = RequestMethod.POST)
    public void UserBuyTimesAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<UserBuyTimes> UserBuyTimesList = userAnalysisDao.findUserBuyTimes(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("UserBuyTimesList",UserBuyTimesList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/UserBuyTimesSourceAjax",method = RequestMethod.GET)
    public void UserBuyTimesSourceAjax(HttpServletResponse response) {
        //获取用户的组成信息
        List<String> UserBuyTimesSource = userAnalysisDao.findUserBuyTimesSource();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("UserBuyTimesSource",UserBuyTimesSource);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    //上网时段
    @RequestMapping("/Online")
    public String Online() {
        return "test/Online";
    }
    @RequestMapping(value="/OnlinePeriodAjax",method = RequestMethod.POST)
    public void OnlinePeriodAjax( HttpServletResponse response,HttpServletRequest request) {
        String selectTime= request.getParameter("selectTime");
        String siteid= request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<OnlinePeriod> OnlinePeriodList = userAnalysisDao.findOnlinePeriod(selectTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("OnlinePeriodList",OnlinePeriodList);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/OnlinePeriodSiteidAjax",method = RequestMethod.GET)
    public void OnlinePeriodSiteidAjax(HttpServletResponse response) {
        //获取用户的组成信息
        List<String> OnlinePeriodSiteid = userAnalysisDao.findOnlinePeriodSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("OnlinePeriodSiteid",OnlinePeriodSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }

    //用户粘度
    @RequestMapping("/UserViscosity")
    public String UserViscosity() {
        return "test/UserViscosity";
    }
    @RequestMapping(value="/HeightUserCalcAjax",method = RequestMethod.POST)
    public void HeightUserCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String startTime= request.getParameter("startTime");
        String endTime= request.getParameter("endTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<HeightUserCalc> HeightUserCalc = userAnalysisDao.findHeightUserCalc(startTime,endTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("HeightUserCalcList",HeightUserCalc);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/HeightUserCalcSiteidAjax",method = RequestMethod.GET)
    public void HeightUserCalcSiteidAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> HeightUserCalcSiteid = userAnalysisDao.findHeightUserCalcSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("HeightUserCalcSiteid",HeightUserCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }

    @RequestMapping(value="/LightUserCalcAjax",method = RequestMethod.POST)
    public void LightUserCalcAjax( HttpServletResponse response,HttpServletRequest request) {
        String startTime= request.getParameter("startTime");
        String endTime= request.getParameter("endTime");
        String siteid=  request.getParameter("siteid");
        String source= request.getParameter("source");
        //获取用户的组成信息
        List<LightUserCalc> LightUserCalc = userAnalysisDao.findLightUserCalc(startTime,endTime,siteid,source);
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("LightUserCalcList",LightUserCalc);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }
    @RequestMapping(value="/LightUserCalcSiteidAjax",method = RequestMethod.GET)
    public void LightUserCalcSiteidAjax(HttpServletResponse response,HttpServletRequest request) {
        //获取用户的组成信息
        List<String> LightUserCalcSiteid = userAnalysisDao.findLightUserCalcSiteid();
        //把获取的数据放在json中
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("LightUserCalcSiteid",LightUserCalcSiteid);
        ResponseUtils.renderJson(response,jsonObject.toString());
    }


    //站点id
    @RequestMapping(value="/findSiteidAjax",method = RequestMethod.POST)
    public void findSiteidAjax(HttpServletResponse response,HttpServletRequest request) {
        List<Site> SiteListSession= (List<Site>) request.getSession().getAttribute("SiteList");

        JSONObject jsonObject = new JSONObject();
        if(SiteListSession==null){
            //获取用户的组成信息
            List<Site> SiteList = userAnalysisDao.findStie(0);
            request.getSession().setAttribute("SiteList",SiteList);
            //把获取的数据放在json中
            jsonObject.put("SiteList",SiteList);
        }else{
          jsonObject.put("SiteList",request.getSession().getAttribute("SiteList"));
        }
        ResponseUtils.renderJson(response,jsonObject.toString());
    }











    //test
    @RequestMapping("/test")
    public String test() {
        return "test/test";
    }

    @RequestMapping("/EventTrends")
    public String EventTrends() {

        System.out.println("进入UserAnalysisController.............");
        return "test/EventTrends";
    }
    @RequestMapping("/EventTrendsToggle")
    public String EventTrendsToggle() {

        System.out.println("进入UserAnalysisController.............");
        return "test/EventTrendsToggle";
    }
    @RequestMapping("/TimeVisitor")
    public String TimeVisitor() {

        System.out.println("进入UserAnalysisController.............");
        return "test/TimeVisitor";
    }
    @RequestMapping("/UserRetention")
    public String UserRetention() {
        userAnalysisDao.findById(1L);
        userAnalysisService.createTest(new Test());
        System.out.println("进入UserAnalysisController.............");
        return "test/UserRetention";
    }
    @RequestMapping("/gender")
    public String gender() {
//        userAnalysisDao.findById(1L);
//
//        userAnalysisService.createTest(new Test());
//        System.out.println("进入UserAnalysisController.............");
        return "test/gender";
    }
    @RequestMapping("/AccessInternet")
    public String AccessInternet() {

//        userAnalysisService.createTest(new Test());
//        System.out.println("进入UserAnalysisController.............");
        return "test/AccessInternet";
    }
//    @RequestMapping("/Consumption")
//    public String Consumption() {
//        userAnalysisDao.findById(1L);
//
//        userAnalysisService.createTest(new Test());
//        System.out.println("进入UserAnalysisController.............");
//        return "test/Consumption";
//    }

}
