
var IndexTime = function () {
  
      
    return {


        init: function () {
            App.addResponsiveHandler(function () {
                IndexTime.initConstellationCharts();
            });

        },
       //时间组件-今天
        initDashboardDaterange: function () {

            $('#dashboard-report-range').daterangepicker({
                    opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment(),
                    endDate: moment(),
                    maxDate: moment(),
                    dateLimit: {
                        days:0,
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Two Days Ago': [moment().subtract('days', 2),  moment().subtract('days', 2)],
                        'Three Days Ago': [moment().subtract('days', 3), moment().subtract('days', 3)],
                        'Four Days Ago': [ moment().subtract('days', 4),  moment().subtract('days', 4)],
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processData(start,end);
                }
            );
            $('#dashboard-report-range span').html( moment().format('YYYY-MM-DD') + ' - ' + moment().format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#dashboard-report-range').show();
        },
        //时间段，默认一周
        initCalcTime: function () {

            $('#dashboard-report-range').daterangepicker({
                    opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment(),
                    endDate: moment(),
                    maxDate: moment(),
                    dateLimit: {
                        months:12
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Last 7 Days': [moment().subtract('days', 6), moment()],
                        'Last 14 Days': [moment().subtract('days', 13), moment()],
                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                        'Last Month': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processData(start,end);
                }
            );
            $('#dashboard-report-range span').html( moment().subtract('days', 7).format('YYYY-MM-DD') + ' - ' +moment().subtract('days', 1).format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#dashboard-report-range').show();
        },
       //时间-昨天
        initUserVitalityTime: function () {

            $('#dashboard-report-range').daterangepicker({
                    opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment(),
                    endDate: moment(),
                    maxDate: moment(),
                    dateLimit: {
                        months:12
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Last 7 Days': [moment().subtract('days', 6), moment()],
                        'Last 30 Days': [moment().subtract('days', 29), moment()],
                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                        'Last Month': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processData(start,end);
                }
            );
            $('#dashboard-report-range span').html( moment().subtract('days', 1).format('YYYY-MM-DD') + ' - ' + moment().subtract('days', 1).format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#dashboard-report-range').show();
        },


       //条形组件
        initStackCharts: function (start,end,stackUrl) {
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,stackUrl);
            function stackControls(start,end,stackUrl) {

                //异步提交获取数据
                if(!window.my_json) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var d2 = [];
                    var d3 = [];
                    var d4 = [];
                    var d5 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "UserCompositionAjax.html",
                        type: "get",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.userCompriseCalcs, function (index, content) {
                                window.my_json[index] = content;
                            })

                                for (var i = 0; i < window.my_json.length; i++) {

                                    // d1.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].registTotal]); //把数据放置到数据列种
                                    // d2.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].newTotal]); //把数据放置到数据列种
                                    // d3.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].oldTotal]); //把数据放置到数据列种
                                    // d4.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].liveTotal]); //把数据放置到数据列种
                                    // d5.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].DeadTotal]); //把 d1.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].registTotal]); //把数据放置到数据列种
                                    d1.push([i+1, window.my_json[i].registTotal]); //把数据放置到数据列种
                                    d2.push([i+1, window.my_json[i].newTotal]); //把数据放置到数据列种
                                    d3.push([i+1, window.my_json[i].oldTotal]); //把数据放置到数据列种
                                    d4.push([i+1, window.my_json[i].liveTotal]); //把数据放置到数据列种
                                    d5.push([i+1, window.my_json[i].deadTotal]); //把数据放置到数据列种
                                    tick1.push([i+1,window.my_json[i].calcDate]);
                            }
                            d=[ { label: "注册客户", data:d1 },
                                { label: "新客户", data:d2  },
                                { label: "老客户", data:d3  },
                                { label: "活跃客户", data:d4  },
                                { label: "沉默客户", data:d5  }]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#stackControls"),
                       a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:5*60*1000,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                // mode:"time",
                                ticks:tick1,
                                // tickFormatter: function (val, axis) {
                                //     var d = new Date(val*1000);
                                //     return d.getUTCDate() + "/" + (d.getUTCMonth() + 1)+"/"+d.getFullYear();
                                // }
                            },

                        });
                }
                function getLocalTime(ns) {
                    // var unixTimestamp = new Date(ns * 1000);
                    // var d = new Date(ns*1000);
                    // return d.getUTCDate() + "/" + (d.getUTCMonth() + 1)+"/"+d.getFullYear();
                    return ns;

                }
            }
        },
        initUserComppsition: function (start,end,siteid,source) {
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,siteid,source);
            function stackControls(start,end,siteid,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var d2 = [];
                    var d3 = [];
                    var d4 = [];
                    var d5 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "UserCompositionAjax.html",
                        data:{"startTime":start,"endTime":end,"siteid":siteid,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.userCompriseCalcs, function (index, content) {
                                window.my_json[index] = content;
                            })

                            for (var i = 0; i < window.my_json.length; i++) {

                                d1.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].registTotal]); //把数据放置到数据列种
                                d2.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].newTotal]); //把数据放置到数据列种
                                d3.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].oldTotal]); //把数据放置到数据列种
                                d4.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].liveTotal]); //把数据放置到数据列种
                                d5.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].deadTotal]); //把 d1.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].registTotal]); //把数据放置到数据列种
                                tick1.push(getLocalTime(window.my_json[i].calcDate));

                            }
                            d=[ { label: "注册客户", data:d1, color:"#92F725",bars: {
                                order: 0
                            }, },
                                { label: "新客户", data:d2 ,color:"#25BFF7", bars: {
                                    order: 1
                                },  },
                                { label: "老客户", data:d3 ,color:"#FFF64A",  bars: {
                                    order: 2
                                }, },
                                { label: "活跃客户", data:d4 ,color:"#FF4A4A",  bars: {
                                    order: 3
                                },  },
                                { label: "沉默客户", data:d5 ,color:"#BB47F5",  bars: {
                                    order: 4
                                },}
                                ]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#stackControls"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    barWidth:0.2*60*1000,
                                    align:"center",

                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                mode:"time",
                                ticks:tick1,
                                tickFormatter: function (val, axis) {
                                    var d = new Date(val*1000);
                                    return d.getFullYear() + "-" + (d.getUTCMonth() + 1)+"-"+d.getUTCDate();
                                }

                            },
                         grid:{
                                hoverable:true,
                         }

                        });

                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }
                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#stackControls").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];
                                   var y1 = item.datapoint[2];
                                var label = item.series.label;
                                showTooltip(item.pageX, item.pageY,label+"："+(y-y1));

                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });
                }
                function getLocalTime(ns) {
                    //将时间戳转为时间格式
                    // var unixTimestamp = new Date(ns * 1000);
                    // var d = new Date(ns*1000);
                    // return d.getUTCDate() + "/" + (d.getUTCMonth() + 1)+"/"+d.getFullYear();
                    //将时间格式的字符串转为时间戳
                    var stringTime = ns;
                    var timestamp2 = (Date.parse(new Date(stringTime)))/1000;
                    return timestamp2;

                }
            }
        },
        //用户组成分时
        // initUserComppsitionHour: function (selectTime,siteid,source) {
        //     if (!jQuery.plot) {
        //         return;
        //     }
        //     stackControls(selectTime,siteid,source);
        //     function stackControls(selectTime,siteid,source) {
        //
        //         //异步提交获取数据
        //         if(true) {
        //             window.my_json = [];
        //             var d = [];
        //             var d1 = [];
        //             var d2 = [];
        //             var d3 = [];
        //             var d4 = [];
        //             var d5 = [];
        //             $.ajax({
        //                 url: "userCompriseCalcsHourAjax.html",
        //                 data:{"selectTime":selectTime,"siteid":siteid,"source":source},
        //                 type: "POST",
        //                 dataType: "json",
        //                 success: function (data) {
        //                     $.each(data.userCompriseCalcsHour, function (index, content) {
        //                         window.my_json[index] = content;
        //                     })
        //                     for (var i = 0; i < window.my_json.length; i++) {
        //                         d1.push([(window.my_json[i].calc_hour), window.my_json[i].registTotal]); //把数据放置到数据列种
        //                         d2.push([(window.my_json[i].calc_hour), window.my_json[i].newTotal]); //把数据放置到数据列种
        //                         d3.push([(window.my_json[i].calc_hour), window.my_json[i].oldTotal]); //把数据放置到数据列种
        //                         d4.push([(window.my_json[i].calc_hour), window.my_json[i].liveTotal]); //把数据放置到数据列种
        //                         d5.push([(window.my_json[i].calc_hour), window.my_json[i].deadTotal]); //把 d1.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].registTotal]); //把数据放置到数据列种
        //                     }
        //                     d=[ { label: "注册客户", data:d1 },
        //                         { label: "新客户", data:d2  },
        //                         { label: "老客户", data:d3  },
        //                         { label: "活跃客户", data:d4  },
        //                         { label: "沉默客户", data:d5  }]
        //                     plotWithOptions(d);
        //                 }
        //             });
        //         }
        //         function plotWithOptions(a) {
        //
        //             $.plot($("#stackControls"), a, {
        //                 series: {
        //                     stack: true,
        //                     bars: {          //设置如何绘图为柱状图时的相关属性
        //                         show: true,
        //                         barWidth:0.5,
        //                     }
        //                 },
        //                 legend: {
        //                     show: true,
        //                     position: "ne",// or "nw" or "se" or "sw"
        //                     noColumns: 0,
        //                 },
        //                 xaxis: {
        //                     ticks:[0,1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],
        //                     min:0,
        //                     max:24,
        //                     labelWidth:24,
        //                     tickFormatter: function (v) {
        //                         return v + "H";
        //                     }
        //                 },
        //                 grid:{
        //                     hoverable:true,
        //                 }
        //
        //             });
        //             //显示插入的html
        //             function showTooltip(x, y, contents) {
        //                 $('<div id="tooltip">' + contents + '</div>').css({
        //                     position: 'absolute',
        //                     display: 'none',
        //                     top: y + 5,
        //                     left: x + 15,
        //                     border: '1px solid #333',
        //                     padding: '4px',
        //                     color: '#fff',
        //                     'border-radius': '3px',
        //                     'background-color': '#333',
        //                     opacity: 0.80
        //                 }).appendTo("body").fadeIn(200);
        //             }
        //             //绑定鼠标移动事件
        //             var previousPoint = null;
        //             $("#stackControls").bind("plothover", function (event, pos, item) {
        //
        //                 $("#x").text(pos.x.toFixed(2));
        //                 $("#y").text(pos.y.toFixed(2));
        //
        //                 if (item) {
        //
        //                     if (previousPoint != item.dataIndex) {
        //                         previousPoint = item.dataIndex;
        //
        //                         $("#tooltip").remove();
        //                         var x = item.datapoint[0].toFixed(2),
        //                             y = item.datapoint[1].toFixed(2);
        //                         var y1 = item.datapoint[2].toFixed(2);
        //                         var label = item.series.label;
        //
        //                         showTooltip(item.pageX, item.pageY,label+"："+(y-y1));
        //                     }
        //                 } else {
        //                     $("#tooltip").remove();
        //                     previousPoint = null;
        //                 }
        //             });
        //         }
        //     }
        // },

        //用户组成分时多曲线
        initUserComppsitionHour: function (selectTime,siteid,source) {
            if (!jQuery.plot) {
                return;
            }
            stackControls(selectTime,siteid,source);
            function stackControls(selectTime,siteid,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var datasets= [];
                    var d1 = [];
                    var d2 = [];
                    var d3 = [];
                    var d4 = [];
                    var d5 = [];
                    $.ajax({
                        url: "userCompriseCalcsHourAjax.html",
                        data:{"selectTime":selectTime,"siteid":siteid,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.userCompriseCalcsHour, function (index, content) {
                                window.my_json[index] = content;
                            })
                            for (var i = 0; i < window.my_json.length; i++) {
                                d1.push([(window.my_json[i].calc_hour), window.my_json[i].registTotal]); //把数据放置到数据列种
                                d2.push([(window.my_json[i].calc_hour), window.my_json[i].newTotal]); //把数据放置到数据列种
                                d3.push([(window.my_json[i].calc_hour), window.my_json[i].oldTotal]); //把数据放置到数据列种
                                d4.push([(window.my_json[i].calc_hour), window.my_json[i].liveTotal]); //把数据放置到数据列种
                                d5.push([(window.my_json[i].calc_hour), window.my_json[i].deadTotal]); //把 d1.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].registTotal]); //把数据放置到数据列种
                            }
                            datasets =[ { label: "注册客户", data:d1 },
                                { label: "新客户", data:d2  },
                                { label: "老客户", data:d3  },
                                { label: "活跃客户", data:d4  },
                                { label: "沉默客户", data:d5  }]
                            plotWithOptions(datasets);
                        }
                    });
                }
                function plotWithOptions(a) {
                    var datasets= a;
                    var i = 0;
                    $.each(datasets, function(key, val) {
                        val.color = i;
                        ++i;
                    });

                    // insert checkboxes插入选择框
                    var choiceContainer = $("#choices");
                    choiceContainer.empty();

                    $.each(datasets, function(key, val) {
                        choiceContainer.append(' &nbsp&nbsp <input type="checkbox" name="' + key +
                            '" checked="checked" id="id' + key + '">' +
                            '<label for="id' + key + '">'
                            + val.label + '</label>');
                    });
                    choiceContainer.find("input").click(plotAccordingToChoices);

                    function plotAccordingToChoices() {//将已经选择的内容的数据取出来
                        var data = [];
                        choiceContainer.find("input:checked").each(function () {
                            var key = $(this).attr("name");
                            if (key && datasets[key])
                                data.push(datasets[key]);
                        });

                        if (data.length > 0)
                            $.plot($("#stackControls"), data, {      //把数据渲染展示出来
                                series: {
                                    lines: {
                                        show: true,
                                        lineWidth: 2,
                                        fill: true,
                                        fillColor: {
                                            colors: [{
                                                opacity: 0.05
                                            }, {
                                                opacity: 0.01
                                            }
                                            ]
                                        }
                                    },
                                    points: {
                                        show: true
                                    },
                                    shadowSize:2
                                },
                                yaxis: { min: 0 },
                                xaxis: { min: 0,max:23,  ticks:[0,1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],tickDecimals: 0,   tickFormatter: function (v) {
                                    return v + "H";
                                } },
                                grid:{hoverable:true,}
                            });
                    }

                    plotAccordingToChoices();
                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }
                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#stackControls").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                         if (item) {

                         if (previousPoint != item.dataIndex) {
                         previousPoint = item.dataIndex;
                          $("#tooltip").remove();
                         var x = item.datapoint[0].toFixed(2);
                         var y = item.datapoint[1].toFixed(2);

                           var label = item.series.label;

                           showTooltip(item.pageX, item.pageY,label+"："+(y));
                                }
                           } else {
                                $("#tooltip").remove();
                                previousPoint = null;
                          }

                    });
                }
            }
        },

        //终端设备
        initDeviceTime: function () {

            $('#dashboard-report-range').daterangepicker({
                    opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment().subtract('days', 1),
                    endDate: moment().subtract('days', 1),
                    maxDate: moment(),
                    dateLimit: {
                      days:0
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Two Days Ago': [moment().subtract('days', 2),  moment().subtract('days', 2)],
                        'Three Days Ago': [moment().subtract('days', 3), moment().subtract('days', 3)],
                        'Four Days Ago': [ moment().subtract('days', 4),  moment().subtract('days', 4)],
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processData(start,end);
                }
            );
            $('#dashboard-report-range span').html( moment().subtract('days', 1).format('YYYY-MM-DD') + ' - ' + moment().subtract('days', 1).format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#dashboard-report-range').show();
        },  //一天的时间
        initDeviceType: function (start,end,source) {

            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source);
            function stackControls(start,end,source) {
                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];

                    var tick1 = [];
                    $.ajax({
                        url: "DeviceTypeAjax.html",
                        data:{"selectTime":start,"siteid":end,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.deviceTypeList, function (index, content) {

                                d1.push([index+1, content.total]); //把数据放置到数据列种
                                tick1.push([index+1,content.deviceType]);
                            })


                            d=[ { data:d1,color:"#FF6666" }]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#deviceType"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },
                            grid: {
                                hoverable: true
                            }
                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#deviceType").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"总数:"+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });

                }

            }
        },
        initDeviceOS: function (start,end,source) {
/*
            alert("DeviceOS="+start+"---"+end+"---"+source);
*/
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source);
            function stackControls(start,end,source) {
                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "DeviceOSAjax.html",
                        data:{"selectTime":start,"siteid":end,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.deviceOSList, function (index, content) {
                                window.my_json[index] = content;

                                d1.push([index+1, content.total]); //把数据放置到数据列种
                                tick1.push([index+1,content.os]);
                            })


                            d=[ { data:d1,color:"#FFFF00"  }]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {

                    $.plot($("#deviceOS"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },
                            grid: {
                                hoverable: true
                            }
                        });

                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#deviceOS").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];
                                showTooltip(item.pageX, item.pageY,"总数:"+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });




                }

            }
        },
        initDeviceBrowser: function (start,end,source) {
/*
            alert("DeviceBrowser="+start+"---"+end+"---"+source);
*/
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source);
            function stackControls(start,end,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "DeviceBrowserAjax.html",
                        data:{"selectTime":start,"siteid":end,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.deviceBrowserList, function (index, content) {
                                window.my_json[index] = content;
                                d1.push([index+1,content.total]); //把数据放置到数据列种
                                tick1.push([index+1, content.browser]);
                            })


                            d=[ { data:d1 ,color:"#009933"}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#deviceBrowser"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },
                            grid: {
                                hoverable: true
                            }
                        });

                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#deviceBrowser").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"总数:"+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });

                }

            }
        },
        //地区客户
        initAreaClient: function (start,end,source) {
/*
            alert("DeviceBrowser="+start+"---"+end+"---"+source);
*/
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source);
            function stackControls(start,end,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "AreaClientAjax.html",
                        data:{"selectTime":start,"siteid":end,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.AreaClientList, function (index, content) {
                                window.my_json[index] = content;
                            })

                            for (var i = 0; i < window.my_json.length; i++) {

                                d1.push([i+1, window.my_json[i].total]); //把数据放置到数据列种
                                tick1.push([i+1, window.my_json[i].area]);

                            }
                            d=[ { data:d1 }]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#areaClientId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },

                            grid: {
                                hoverable: true
                            }

                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#areaClientId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"总数:"+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });


                }

            }
        },
        //商品分析
        initGoodsSellTime: function () {

            $('#GoodsSellTimeId').daterangepicker({  opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment().subtract('days', 1),
                    endDate: moment().subtract('days', 1),
                    maxDate: moment(),
                    dateLimit: {
                        days:0
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Two Days Ago': [moment().subtract('days', 2),  moment().subtract('days', 2)],
                        'Three Days Ago': [moment().subtract('days', 3), moment().subtract('days', 3)],
                        'Four Days Ago': [ moment().subtract('days', 4),  moment().subtract('days', 4)],
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processDataGoodsSell(start,end);
                }
            );
            $('#GoodsSellTimeId span').html(moment().subtract('days', 1).format('YYYY-MM-DD') + ' - ' +moment().subtract('days', 1).format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#GoodsSellTimeId').show();
        },
        initKeyWordTime: function () {

            $('#KeyWordTimeId').daterangepicker({  opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment().subtract('days', 1),
                    endDate: moment().subtract('days', 1),
                    maxDate: moment(),
                    dateLimit: {
                        days:0
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Two Days Ago': [moment().subtract('days', 2),  moment().subtract('days', 2)],
                        'Three Days Ago': [moment().subtract('days', 3), moment().subtract('days', 3)],
                        'Four Days Ago': [ moment().subtract('days', 4),  moment().subtract('days', 4)],
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processDataKeyWord(start,end);
                }
            );
            $('#KeyWordTimeId span').html(moment().subtract('days', 1).format('YYYY-MM-DD') + ' - ' +moment().subtract('days', 1).format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#KeyWordTimeId').show();
        },
        initOrderCalcTime: function () {

            $('#OrderCalcTimeId').daterangepicker({
                    opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment(),
                    endDate: moment(),
                    maxDate: moment(),
                    dateLimit: {
                        months:12
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Last 7 Days': [moment().subtract('days', 6), moment()],
                        'Last 30 Days': [moment().subtract('days', 29), moment()],
                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                        'Last Month': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processDataOrderCalc(start,end);
                }
            );
            $('#OrderCalcTimeId span').html( moment().subtract('days', 7).format('YYYY-MM-DD') + ' - ' +moment().subtract('days', 1).format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#OrderCalcTimeId').show();
        },
        initOrderCalcScaleTime: function () {

            $('#OrderCalcScaleTimeId').daterangepicker({
                    opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment(),
                    endDate: moment(),
                    maxDate: moment(),
                    dateLimit: {
                        months:12
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Last 7 Days': [moment().subtract('days', 6), moment()],
                        'Last 30 Days': [moment().subtract('days', 29), moment()],
                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                        'Last Month': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processDataOrderCalcScale(start,end);
                }
            );
            $('#OrderCalcScaleTimeId span').html( moment().subtract('days', 7).format('YYYY-MM-DD') + ' - ' +moment().subtract('days', 1).format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#OrderCalcScaleTimeId').show();
        },

        initGoodsSell: function(selectTimeGoodsSell,siteid,source) {
/*
            alert("DeviceBrowser="+selectTimeGoodsSell+"-----"+siteid+"---"+source);
*/
            if (!jQuery.plot) {
                return;
            }
            stackControls(selectTimeGoodsSell,siteid,source);
            function stackControls(selectTimeGoodsSell,siteid,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];

                    var tick1 = [];
                    $.ajax({
                        url: "GoodsSellAjax.html",
                        data:{"selectTime":selectTimeGoodsSell,"siteid":siteid,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.GoodsSellList, function (index, content) {
                                window.my_json[index] = content;
                            })

                            for (var i = 0; i < window.my_json.length; i++) {

                                d1.push([i+1, window.my_json[i].total]); //把数据放置到数据列种
                                tick1.push([i+1, window.my_json[i].ecitemname]);

                            }
                            d=[ { data:d1,color:"#CC0066"}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#GoodsSellId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },


                            grid: {
                                hoverable: true
                            }

                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#GoodsSellId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"总数:"+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });

                }

            }
        },
        initKeyWord: function (start,siteid,source) {
/*
            alert("DeviceBrowser="+start+"------"+source);
*/
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,siteid,source);
            function stackControls(start,siteid,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];

                    var tick1 = [];
                    $.ajax({
                        url: "KeyWordAjax.html",
                        data:{"selectTime":start,"siteid":siteid,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.KeyWordList, function (index, content) {
                                window.my_json[index] = content;
                            })

                            for (var i = 0; i < window.my_json.length; i++) {

                                d1.push([i+1, window.my_json[i].total]); //把数据放置到数据列种
                                tick1.push([i+1, window.my_json[i].keyword]);

                            }
                            d=[ { data:d1,color:"#FFFF00"}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#KeyWordId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },


                            grid: {
                                hoverable: true
                            }

                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#KeyWordId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"总数:"+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });

                }

            }
        },
        initOrderCalc: function (start,end,siteid,source) {

            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,siteid,source);
            function stackControls(start,end,siteid,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var d2 = [];
                    var d3 = [];

                    var tick1 = [];
                    $.ajax({
                        url: "OrderCalcAjax.html",
                        data:{"startTime":start,"endTime":end,"siteid":siteid,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.OrderCalcList, function (index, content) {

                                d1.push([getLocalTime(content.calcDate), content.total]); //把数据放置到数据列种
                                d2.push([getLocalTime(content.calcDate), content.unpayTotal]); //把数据放置到数据列种
                                d3.push([getLocalTime(content.calcDate), content.payTotal]); //把数据放置到数据列种
                                tick1.push(getLocalTime(content.calcDate));
                            })

                            // for (var i = 0; i < window.my_json.length; i++) {
                            //
                            //     d1.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].total]); //把数据放置到数据列种
                            //     d2.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].unpayTotal]); //把数据放置到数据列种
                            //     d3.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].payTotal]); //把数据放置到数据列种
                            //     tick1.push(getLocalTime(window.my_json[i].calcDate));
                            //
                            // }
                            d=[ { label: "订单数", data:d1,bars: {
                                order: 0
                            }, },
                                { label: "未付款订单数", data:d2 ,bars: {
                                    order: 1
                                }, },
                                { label: "已付款订单数", data:d3,bars: {
                                    order: 2
                                },},
                               ]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#OrderCalcId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {

                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    barWidth:0.2*60*1000,
                                    align:"center",
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                mode:"time",
                                ticks:tick1,
                                tickFormatter: function (val, axis) {
                                    var d = new Date(val*1000);
                                    return d.getFullYear() + "-" + (d.getUTCMonth() + 1)+"-"+d.getUTCDate();
                                }
                            },
                            grid: {
                                hoverable: true
                            }

                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#OrderCalcId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);
                                var y1 = item.datapoint[2].toFixed(2);
                                var label = item.series.label;
                                showTooltip(item.pageX, item.pageY,label+"："+(y-y1));
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });

                }
                function getLocalTime(ns) {
                    //将时间戳转为时间格式
                    // var unixTimestamp = new Date(ns * 1000);
                    // var d = new Date(ns*1000);
                    // return d.getUTCDate() + "/" + (d.getUTCMonth() + 1)+"/"+d.getFullYear();
                    //将时间格式的字符串转为时间戳
                    var stringTime = ns;
                    var timestamp2 = (Date.parse(new Date(stringTime)))/1000;
                    return timestamp2;

                }
            }
        },
        initOrderCalcScale: function (start,end,siteid,source) {

            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,siteid,source);
            function stackControls(start,end,siteid,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];

                    var d4 = [];
                    var d5 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "OrderCalcAjax.html",
                        data:{"startTime":start,"endTime":end,"siteid":siteid,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.OrderCalcList, function (index, content) {

                                d4.push([getLocalTime(content.calcDate), content.unpayPrecent]); //把数据放置到数据列种
                                d5.push([getLocalTime(content.calcDate), content.payPrecent]); //把 d1.push([getLocalTime(window.my_json[i].calcDate), window.my_json[i].registTotal]); //把数据放置到数据列种
                                tick1.push(getLocalTime(content.calcDate));
                            })

                            d=[
                                { label: "未付款占比", data:d4 ,bars: {
                                    order: 0
                                },  },
                                { label: "已付款占比", data:d5  ,bars: {
                                    order:1
                                }, }]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#OrderCalcScaleId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {

                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    barWidth:0.2*60*1000,
                                    // barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                mode:"time",
                                ticks:tick1,
                                tickFormatter: function (val, axis) {
                                    var d = new Date(val*1000);
                                    return d.getFullYear() + "-" + (d.getUTCMonth() + 1)+"-"+d.getUTCDate();
                                }
                            },
                            grid: {
                                hoverable: true
                            }

                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#OrderCalcScaleId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);
                                var y1 = item.datapoint[2].toFixed(2);
                                var label = item.series.label;
                                showTooltip(item.pageX, item.pageY,label+"："+(y-y1));
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });

                }
                function getLocalTime(ns) {
                    //将时间戳转为时间格式
                    // var unixTimestamp = new Date(ns * 1000);
                    // var d = new Date(ns*1000);
                    // return d.getUTCDate() + "/" + (d.getUTCMonth() + 1)+"/"+d.getFullYear();
                    //将时间格式的字符串转为时间戳
                    var stringTime = ns;
                    var timestamp2 = (Date.parse(new Date(stringTime)))/1000;
                    return timestamp2;

                }
            }
        },

        //用户粘度
        initVitalityCalc: function (start,end,source,siteid) {
/*
            alert("VitalityCalc="+start+"---"+end+"---"+source+"---"+siteid);
*/
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source,siteid);
            function stackControls(start,end,source,siteid) {
                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var d2= [];
                    var d3 = [];

                    var tick1 = [];
                    $.ajax({
                        url: "VitalityCalcAjax.html",
                        data:{"startTime":start,"endTime":end,"source":source,"siteid":siteid},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.VitalityCalcList, function (index, content) {
                                window.my_json[index] = content;
                            })

                            for (var i = 0; i < window.my_json.length; i++) {

                                d1.push([window.my_json[i].hour, window.my_json[i].pv]); //把数据放置到数据列种
                                d2.push([window.my_json[i].hour, window.my_json[i].uv]); //把数据放置到数据列种
                                d3.push([window.my_json[i].hour, window.my_json[i].ip]); //把数据放置到数据列种
                                // tick1.push( window.my_json[i].hour);

                            }
                            d=[ { label: "PV",  data:d1 },{label: "UV",  data:d2 },{ label: "IP", data:d3 }];
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#VitalityCalcId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                lines: {
                                    show: true,
                                    lineWidth: 2,
                                    fill: true,
                                    fillColor: {
                                        colors: [{
                                            opacity: 0.05
                                        }, {
                                            opacity: 0.01
                                        }
                                        ]
                                    }
                                },
                                points: {
                                    show: true
                                },
                                shadowSize:2
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:[0,1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],
                                min:0,
                                max:24,
                                labelWidth:24,
                                tickFormatter: function (v) {
                                    return v + "H";
                                }
                            },


                            grid: {
                                hoverable: true
                            }

                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#VitalityCalcId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];
                                var y1 = item.datapoint[2].toFixed(2);
                                var label = item.series.label;

                                showTooltip(item.pageX, item.pageY,label+"："+(y-y1));

                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });

                }            }
        },

        //用户画像
        initAgeCalc: function (start,end,source) {

            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source);
            function stackControls(start,end,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "AgeCalcAjax.html",
                        data:{"selectTime":start,"siteid":end,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.AgeCalcList, function (index, content) {

                                d1.push([ index+1, content.total]); //把数据放置到数据列种
                                tick1.push([index+1,content.age+"岁"]);
                            })
                            d=[ { data:d1 ,color:"#FF0033"}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#ageCalc"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,

                            },



                            grid: {
                                hoverable: true
                            }

                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#ageCalc").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"总数:"+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });

                }

            }
        },
        initSexCalc: function (start,end,source) {

            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source);
            function stackControls(start,end,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "SexCalcAjax.html",
                        data:{"selectTime":start,"siteid":end,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.SexCalcList, function (index, content) {
                                d1.push([index+1,content.total]); //把数据放置到数据列种
                                tick1.push([index+1, content.sex]);
                            })

                            d=[ { data:d1 ,color:"#333399"}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#sexCalc"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                                min:0,
                            },
                            grid: {
                                hoverable: true
                            }
                        });
                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }
                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#sexCalc").bind("plothover", function (event, pos, item) {
                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));
                        if (item) {
                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;
                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"总数:"+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });


                }

            }
        },
        
        //消费情况
        initComsumptionTime: function () {

            $('#dashboard-report-range').daterangepicker({
                    opens: (App.isRTL() ? 'right' : 'left'),
                    startDate: moment().subtract('days', 1),
                    endDate: moment().subtract('days', 1),
                    maxDate: moment(),
                    dateLimit: {
                        days:0
                    },
                    showDropdowns: false,
                    showWeekNumbers: true,
                    timePicker: false,
                    timePickerIncrement: 1,
                    timePicker12Hour: false,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
                        'Two Days Ago': [moment().subtract('days', 2),  moment().subtract('days', 2)],
                        'Three Days Ago': [moment().subtract('days', 3), moment().subtract('days', 3)],
                        'Four Days Ago': [ moment().subtract('days', 4),  moment().subtract('days', 4)],
                    },
                    buttonClasses: ['btn'],
                    applyClass: 'blue',
                    cancelClass: 'default',
                    format: 'YYYY-MM-DD',
                    separator: ' to ',
                    locale: {
                        applyLabel: 'Apply',
                        fromLabel: 'From',
                        toLabel: 'To',
                        customRangeLabel: 'Custom Range',
                        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
                        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        firstDay: 1
                    }
                },
                function (start, end) {   //选择日期后出发的方法
                    console.log("Callback has been called!");
                    processData(start,end);
                }
            );
            $('#dashboard-report-range span').html( moment().subtract('days', 1).format('YYYY-MM-DD') + ' - ' + moment().subtract('days', 1).format('YYYY-MM-DD')); //显示在组件横栏上的时间
            $('#dashboard-report-range').show();
        },
        initGoodsSellCustomer: function (start,end,source) {
/*
            alert("GoodsSellCustomer="+start+"---"+end+"---"+source);
*/
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source);
            function stackControls(start,end,source) {
                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];

                    var tick1 = [];
                    $.ajax({
                        url: "GoodsSellCustomerAjax.html",
                        data:{"selectTime":start,"siteid":end,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.GoodsSellCustomerList, function (index, content) {

                                d1.push([index+1, content.times]); //把数据放置到数据列种
                                tick1.push([index+1, content.ecitemname]);
                            })

                            d=[ { data:d1 ,color:"#FF6666"}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#GoodsSellCustomer"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },

                            grid:{
                                hoverable:true,
                            }

                        });
                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#GoodsSellCustomer").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"次数："+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });
                }

            }
        },
        initUserBuyTimes: function (start,end,source) {

            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source);
            function stackControls(start,end,source) {
                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "UserBuyTimesAjax.html",
                        data:{"selectTime":start,"siteid":end,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.UserBuyTimesList, function (index, content) {
                                d1.push([index+1, content.total]); //把数据放置到数据列种
                                tick1.push([index+1, (content.times+"次")]);
                            })


                            d=[ { data:d1 ,color:"#00CC00"}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {

                    $.plot($("#UserBuyTimes"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },
                            grid:{
                                hoverable:true,
                            }

                        });



                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#UserBuyTimes").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY,"总数："+ y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });


                }

            }
        },
        initAreaOrder: function (selectTime,siteid,area,source) {

            if (!jQuery.plot) {
                return;
            }
            stackControls(selectTime,siteid,area,source);
            function stackControls(selectTime,siteid,area,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];

                    var tick1 = [];
                    $.ajax({
                        url: "findAreaOrderByAreaSourceAjax.html",
                        data:{"selectTime":selectTime,"siteid":siteid,"area":area,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.AreaOrderList, function (index, content) {

                                d1.push([index+1, content.total]); //把数据放置到数据列种
                                tick1.push([index+1, content.ecitemname]);
                            })

                            d=[ { data:d1 ,color:"#0099CC"}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#AreaOrder"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                stack: true,
                                bars: {          //设置如何绘图为柱状图时的相关属性
                                    show: true,
                                    // barWidth:1,
                                    barWidth:0.5,
                                }
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:tick1,
                            },
                            grid: {
                                hoverable: true
                            }

                        });


                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#AreaOrder").bind("hoverable", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1];

                                showTooltip(item.pageX, item.pageY, "总数："+y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });





                }

            }
        },

        //上网时段
        initOnlinePeriod: function (selectTime,siteid,source) {
            if (!jQuery.plot) {
                return;
            }
            stackControls(selectTime,siteid,source);
            function stackControls(selectTime,siteid,source) {

                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "OnlinePeriodAjax.html",
                        data:{"selectTime":selectTime,"siteid":siteid,"source":source},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.OnlinePeriodList, function (index, content) {
                                window.my_json[index] = content;
                            })

                            for (var i = 0; i < window.my_json.length; i++) {

                                d1.push([window.my_json[i].hours, window.my_json[i].total]); //把数据放置到数据列种

                            }
                            d=[ { label: "在线用户数", data:d1}]
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#OnlinePeriodId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                lines: {
                                    show: true,
                                    lineWidth: 2,
                                    fill: true,
                                    fillColor: {
                                        colors: [{
                                            opacity: 0.05
                                        }, {
                                            opacity: 0.01
                                        }
                                        ]
                                    }
                                },
                                points: {
                                    show: true
                                },
                                shadowSize:2
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                ticks:[0,1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23],
                                min:0,
                                max:24,
                                labelWidth:24,
                                tickFormatter: function (v) {
                                    return v + "H";
                                }
                            },
                            grid: {
                                hoverable: true
                            }
                        });



                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#OnlinePeriodId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);

                                showTooltip(item.pageX, item.pageY, "用户数："+y);
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });




                }

            }
        },
        //用户粘度
        initHeightUserCalc: function (start,end,source,siteid) {

            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source,siteid);
            function stackControls(start,end,source,siteid) {
                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var d2= [];
                    var d4 = [];
                    var tick1 = [];
                    $.ajax({
                        url: "HeightUserCalcAjax.html",
                        data:{"startTime":start,"endTime":end,"source":source,"siteid":siteid},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.HeightUserCalcList, function (index, content) {

                                d1.push([getLocalTime(content.calc_date), (content.user_precent_times)*100]); //把数据放置到数据列种
                                d2.push([getLocalTime(content.calc_date), (content.user_precent_length)*100]); //把数据放置到数据列种
                                d4.push([getLocalTime(content.calc_date), (content.page_precent)*100]); //把数据放置到数据列种
                                tick1.push(getLocalTime(content.calc_date));
                            })


                            d=[ { label: "重度用户比例",  data:d1 ,color:"#0066CC"},
                                {label: "重度用户比例(时长)",  data:d2 ,color:"#FFFF00"},
                                { label: "重度访问量比例", data:d4,color:"#FF6666"}
                                ];
                            plotWithOptions(d);
                        }
                    });
                }
                function plotWithOptions(a) {
                    $.plot($("#HeightUserCalcId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            // series: {
                            //     stack: true,
                            //     bars: {          //设置如何绘图为柱状图时的相关属性
                            //         show: true,
                            //         align:"center",
                            //         barWidth:0.5*60*1000,
                            //         // barWidth:0.5,
                            //     }
                            // },
                            series: {
                                lines: {
                                    show: true,
                                    lineWidth: 2,
                                    fill: true,
                                    fillColor: {
                                        colors: [{
                                            opacity: 0.05
                                        }, {
                                            opacity: 0.01
                                        }
                                        ]
                                    }
                                },
                                points: {
                                    show: true
                                },
                                shadowSize:2
                            },
                            legend: {
                                show: true,
                                position: "ne",
                                noColumns: 0,
                            },
                            xaxis: {
                                mode:"time",
                                ticks:tick1,
                                tickFormatter: function (val, axis) {
                                    var d = new Date(val*1000);
                                    return d.getFullYear() + "-" + (d.getUTCMonth() + 1)+"-"+d.getUTCDate();
                                }

                            },
                            yaxis: {
                                ticks:[0,20,40,60,80,100],
                                tickFormatter: function (val, axis) {
                                    return val+"%";
                                }
                            },
                            grid: {
                                hoverable: true
                            }

                        });
                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }
                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#HeightUserCalcId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);
                                var y1 = item.datapoint[2].toFixed(2);
                                var label = item.series.label;
                                showTooltip(item.pageX, item.pageY,label+"："+(y-y1)+"%");
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });
                }
                function getLocalTime(ns) {
                    //将时间格式的字符串转为时间戳
                    var stringTime = ns;
                    var timestamp2 = (Date.parse(new Date(stringTime)))/1000;
                    return timestamp2;

                }
            }
        },
        initLightUserCalc: function (start,end,source,siteid) {
        if (!jQuery.plot) {
            return;
        }
        stackControls(start,end,source,siteid);
        function stackControls(start,end,source,siteid) {
            //异步提交获取数据
            if(true) {
                window.my_json = [];
                var d = [];
                var d1 = [];
                var d3 = [];

                var tick1 = [];
                $.ajax({
                    url: "LightUserCalcAjax.html",
                    data:{"startTime":start,"endTime":end,"source":source,"siteid":siteid},
                    type: "POST",
                    dataType: "json",
                    success: function (data) {
                        $.each(data.LightUserCalcList, function (index, content) {
                            d1.push([getLocalTime(content.calc_date), (content.user_precent)*100]); //把数据放置到数据列种
                            d3.push([getLocalTime(content.calc_date), (content.page_precent)*100]); //把数据放置到数据列种
                            tick1.push(getLocalTime(content.calc_date));
                        })
                        d=[ { label: "轻度用户比例",  data:d1 },
                            { label: "轻度访问量比例", data:d3 }];
                        plotWithOptions(d);
                    }
                });
            }
            function plotWithOptions(a) {
                $.plot($("#LightUserCalcId"),
                    a, //导入数据，显示对应的数据名称
                    {
                        series: {
                            lines: {
                                show: true,
                                lineWidth: 2,
                                fill: true,
                                fillColor: {
                                    colors: [{
                                        opacity: 0.05
                                    }, {
                                        opacity: 0.01
                                    }
                                    ]
                                }
                            },
                            points: {
                                show: true
                            },
                            shadowSize:2
                        },
                        legend: {
                            show: true,
                            position: "ne",
                            noColumns: 0,
                        },
                        xaxis: {
                            mode:"time",
                            ticks:tick1,
                            tickFormatter: function (val, axis) {
                                var d = new Date(val*1000);
                                return d.getFullYear() + "-" + (d.getUTCMonth() + 1)+"-"+d.getUTCDate();
                            }
                        },
                        yaxis: {
                            ticks:[0,20,40,60,80,100],
                            tickFormatter: function (val, axis) {
                                return val+"%";
                            }
                        },
                        grid: {
                            hoverable: true
                        }
                    });
                //显示插入的html
                function showTooltip(x, y, contents) {
                    $('<div id="tooltip">' + contents + '</div>').css({
                        position: 'absolute',
                        display: 'none',
                        top: y + 5,
                        left: x + 15,
                        border: '1px solid #333',
                        padding: '4px',
                        color: '#fff',
                        'border-radius': '3px',
                        'background-color': '#333',
                        opacity: 0.80
                    }).appendTo("body").fadeIn(200);
                }
                //绑定鼠标移动事件
                var previousPoint = null;
                $("#LightUserCalcId").bind("plothover", function (event, pos, item) {

                    $("#x").text(pos.x.toFixed(2));
                    $("#y").text(pos.y.toFixed(2));

                    if (item) {
                        if (previousPoint != item.dataIndex) {
                            previousPoint = item.dataIndex;
                            $("#tooltip").remove();
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);
                            var y1 = item.datapoint[2].toFixed(2);
                            var label = item.series.label;
                            showTooltip(item.pageX, item.pageY,label+"："+(y-y1)+"%");
                        }
                    } else {
                        $("#tooltip").remove();
                        previousPoint = null;
                    }
                });
            }
            function getLocalTime(ns) {
                //将时间格式的字符串转为时间戳
                var stringTime = ns;
                var timestamp2 = (Date.parse(new Date(stringTime)))/1000;
                return timestamp2;

            }
        }
    },
        initUserCalc: function (start,end,source,siteid) {
            if (!jQuery.plot) {
                return;
            }
            stackControls(start,end,source,siteid);
            function stackControls(start,end,source,siteid) {
                //异步提交获取数据
                if(true) {
                    window.my_json = [];
                    var d = [];
                    var d1 = [];
                    var d2= [];
                    var d3 = [];
                    var d4 = [];

                    var tick1 = [];
                    $.ajax({
                        url: "HeightUserCalcAjax.html",
                        data:{"startTime":start,"endTime":end,"source":source,"siteid":siteid},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.HeightUserCalcList, function (index, content) {
                                d3.push([getLocalTime(content.calc_date), content.user_index]); //把数据放置到数据列种
                            })
                        }
                    });
                    $.ajax({
                        url: "LightUserCalcAjax.html",
                        data:{"startTime":start,"endTime":end,"source":source,"siteid":siteid},
                        type: "POST",
                        dataType: "json",
                        success: function (data) {
                            $.each(data.LightUserCalcList, function (index, content) {
                                // d1.push([getLocalTime(content.calc_date), content.user_precent]); //把数据放置到数据列种
                                d2.push([getLocalTime(content.calc_date), content.user_index]); //把数据放置到数据列种
                                tick1.push(getLocalTime(content.calc_date));
                            })


                            d=[
                                {label: "轻度用户指数",  data:d2, color:"#CC0033"},
                                { label: "重度用户指数", data:d3 ,color:"#CC9966"}
                                ];
                            plotWithOptions(d);
                        }
                    });

                }
                function plotWithOptions(a) {
                    $.plot($("#UserCalcId"),
                        a, //导入数据，显示对应的数据名称
                        {
                            series: {
                                lines: {
                                    show: true,
                                    lineWidth: 2,
                                    fill: true,
                                    fillColor: {
                                        colors: [{
                                            opacity: 0.05
                                        }, {
                                            opacity: 0.01
                                        }
                                        ]
                                    }
                                },
                                points: {
                                    show: true
                                },
                                shadowSize:2
                            },
                            legend: {
                                show: true,
                                position: "ne",// or "nw" or "se" or "sw"
                                noColumns: 0,
                            },
                            xaxis: {
                                mode:"time",
                                ticks:tick1,
                                tickFormatter: function (val, axis) {
                                    var d = new Date(val*1000);
                                    return d.getFullYear() + "-" + (d.getUTCMonth() + 1)+"-"+d.getUTCDate();
                                }
                            },

                            grid: {
                                hoverable: true
                            }
                        });
                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }
                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#UserCalcId").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);
                                var y1 = item.datapoint[2].toFixed(2);
                                var label = item.series.label;
                                showTooltip(item.pageX, item.pageY,label+"："+(y-y1));
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });
                }
                function getLocalTime(ns) {
                    //将时间格式的字符串转为时间戳
                    var stringTime = ns;
                    var timestamp2 = (Date.parse(new Date(stringTime)))/1000;
                    return timestamp2;

                }
            }
        },
        //曲线组件
        initInteractiveCharts: function () {

            if (!jQuery.plot) {
                return;
            }

            //Interactive Chart
            function InteractiveChart() {
                function randValue() {
                    return (Math.floor(Math.random() * (1 + 40 - 20))) + 20;
                }

                //数据
                var visitors = [
                    [gd(2013, 1, 2), randValue() - 5],
                    [gd(2013, 1, 3), randValue() - 5],
                    [gd(2013, 1, 4), randValue() - 5],
                    [gd(2013, 1, 5), 6 + randValue()],
                    [gd(2013, 1, 6), 5 + randValue()],
                    [gd(2013, 1, 7), 20 + randValue()],
                    [gd(2013, 1, 8), 25 + randValue()],
                    [gd(2013, 1, 9), 36 + randValue()],
                    [gd(2013, 1, 10), 26 + randValue()],
                    [gd(2013, 1, 11), 38 + randValue()],
                    [gd(2013, 1, 12), 39 + randValue()],
                    [gd(2013, 1, 13), 50 + randValue()],
                    [gd(2013, 1, 14), 51 + randValue()],
                    [gd(2013, 1, 15), 12 + randValue()],
                    [gd(2013, 1, 16), 13 + randValue()],
                    [gd(2013, 1, 17), 14 + randValue()],
                    [gd(2013, 1, 18), 15 + randValue()]

                ];

                var plot = $.plot($("#interactiveChart"),
                    [{data: visitors, label: "Page Views"}], //显示数据线的数据和名称
                    {
                        series: {
                            lines: {
                                show: true,
                                lineWidth: 2,
                                fill: true,
                                fillColor: {
                                    colors: [{
                                        opacity: 0.05
                                    }, {
                                        opacity: 0.01
                                    }
                                    ]
                                }
                            },
                            points: {
                                show: true
                            },
                            shadowSize:2
                        },
                        grid: {
                            hoverable: true,
                            clickable: true,
                            tickColor: "#eee",
                            borderWidth: 0
                        },
                        colors: ["#d12610", "#37b7f3", "#52e136"],
                        xaxis: {
                            mode:"time",
                            timeformat: "%y/%m/%d",
                            // tickFormatter: function (val, axis) {
                            //     var d = new Date(val);
                            //     return d.getUTCDate() + "/" + (d.getUTCMonth() + 1);
                            // }
                        },
                        yaxis: {
                            ticks: 11,
                            tickDecimals: 0
                        }
                    });
                //转化时间
                function gd(year, month, day) {
                    return new Date(year, month - 1, day).getTime();
                }
                function timeFormatter(val) {
                    // var d = new Date(val).Format("yyyy-MM-dd");
                    return  new Date(val);
                }

                //显示节点的数据的工具类
                function showTooltip(x, y, contents) {
                    $('<div id="tooltip">' + contents + '</div>').css({
                        position: 'absolute',
                        display: 'none',
                        top: y + 5,
                        left: x + 15,
                        border: '1px solid #333',
                        padding: '4px',
                        color: '#fff',
                        'border-radius': '3px',
                        'background-color': '#333',
                        opacity: 0.80
                    }).appendTo("body").fadeIn(200);
                }
                //绑定鼠标聚焦事件
                var previousPoint = null;
                $("#interactiveChart").bind("plotclick", function (event, pos, item) {
                    $("#x").text(pos.x.toFixed(2));
                    $("#y").text(pos.y.toFixed(2));

                    if (item) {
                        if (previousPoint != item.dataIndex) {
                            previousPoint = item.dataIndex;
                            $("#tooltip").remove();
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);

                            showTooltip(item.pageX, item.pageY, timeFormatter(item.series.label) + " of " + x + " = " + y);
                        }
                    } else {
                        $("#tooltip").remove();
                        previousPoint = null;
                    }
                });
            }
            // graph图表
            InteractiveChart();

        },
        //多曲线组件-趋势
        initTogglingCharts:function() {
            if (!jQuery.plot) {
                return;
            }
            //TogglingCharts
            function TogglingCharts() {
                var datasets = {
                    "usa": {
                        label: "USA",
                        data: [[1988, 483994], [1989, 479060], [1990, 457648], [1991, 401949], [1992, 424705], [1993, 402375], [1994, 377867], [1995, 357382], [1996, 337946], [1997, 336185], [1998, 328611], [1999, 329421], [2000, 342172], [2001, 344932], [2002, 387303], [2003, 440813], [2004, 480451], [2005, 504638], [2006, 528692]]
                    },
                    "russia": {
                        label: "Russia",
                        data: [[1988, 218000], [1989, 203000], [1990, 171000], [1992, 42500], [1993, 37600], [1994, 36600], [1995, 21700], [1996, 19200], [1997, 21300], [1998, 13600], [1999, 14000], [2000, 19100], [2001, 21300], [2002, 23600], [2003, 25100], [2004, 26100], [2005, 31100], [2006, 34700]]
                    },
                    "uk": {
                        label: "UK",
                        data: [[1988, 62982], [1989, 62027], [1990, 60696], [1991, 62348], [1992, 58560], [1993, 56393], [1994, 54579], [1995, 50818], [1996, 50554], [1997, 48276], [1998, 47691], [1999, 47529], [2000, 47778], [2001, 48760], [2002, 50949], [2003, 57452], [2004, 60234], [2005, 60076], [2006, 59213]]
                    },
                    "germany": {
                        label: "Germany",
                        data: [[1988, 55627], [1989, 55475], [1990, 58464], [1991, 55134], [1992, 52436], [1993, 47139], [1994, 43962], [1995, 43238], [1996, 42395], [1997, 40854], [1998, 40993], [1999, 41822], [2000, 41147], [2001, 40474], [2002, 40604], [2003, 40044], [2004, 38816], [2005, 38060], [2006, 36984]]
                    },
                    "denmark": {
                        label: "Denmark",
                        data: [[1988, 3813], [1989, 3719], [1990, 3722], [1991, 3789], [1992, 3720], [1993, 3730], [1994, 3636], [1995, 3598], [1996, 3610], [1997, 3655], [1998, 3695], [1999, 3673], [2000, 3553], [2001, 3774], [2002, 3728], [2003, 3618], [2004, 3638], [2005, 3467], [2006, 3770]]
                    },
                    "sweden": {
                        label: "Sweden",
                        data: [[1988, 6402], [1989, 6474], [1990, 6605], [1991, 6209], [1992, 6035], [1993, 6020], [1994, 6000], [1995, 6018], [1996, 3958], [1997, 5780], [1998, 5954], [1999, 6178], [2000, 6411], [2001, 5993], [2002, 5833], [2003, 5791], [2004, 5450], [2005, 5521], [2006, 5271]]
                    },
                    "norway": {
                        label: "Norway",
                        data: [[1988, 4382], [1989, 4498], [1990, 4535], [1991, 4398], [1992, 4766], [1993, 4441], [1994, 4670], [1995, 4217], [1996, 4275], [1997, 4203], [1998, 4482], [1999, 4506], [2000, 4358], [2001, 4385], [2002, 5269], [2003, 5066], [2004, 5194], [2005, 4887], [2006, 4891]]
                    }
                };

                // hard-code color indices to prevent them from shifting as
                // countries are turned on/off
                var i = 0;
                $.each(datasets, function(key, val) {
                    val.color = i;
                    ++i;
                });

                // insert checkboxes插入选择框
                var choiceContainer = $("#choices");
                $.each(datasets, function(key, val) {
                    choiceContainer.append(' &nbsp&nbsp <input type="checkbox" name="' + key +
                        '" checked="checked" id="id' + key + '">' +
                        '<label for="id' + key + '">'
                        + val.label + '</label>');
                });
                choiceContainer.find("input").click(plotAccordingToChoices);

                function plotAccordingToChoices() {//将已经选择的内容的数据取出来
                    var data = [];
                    choiceContainer.find("input:checked").each(function () {
                        var key = $(this).attr("name");
                        if (key && datasets[key])
                            data.push(datasets[key]);
                    });

                    if (data.length > 0)
                        $.plot($("#placeholder"), data, {      //把数据渲染展示出来
                            yaxis: { min: 0 },
                            xaxis: { tickDecimals: 0 }
                        });
                }

                plotAccordingToChoices();
            }

            // graph图表
            TogglingCharts();


        },
        //实时访客组件
        initTimeVisitor:function (){

            function TimeVisitor() {
                 var data= {"xj":[{"firstName":"Brett","lastName":"McLaughlin","email":"aaaa"}, {"firstName":"Jason","lastName":"Hunter","email":"bbbb"}, {"firstName":"Elliotte","lastName":"Harold","email":"cccc"}]}

              //遍历每个对象
                window.my_json=[];

                $.each(data, function(key1, val) {
                    // 将表格数据动态的添加到页面上展示
                    window.my_json=val;
                });

                // 将表格数据动态的添加到页面上展示
                var choiceContainer = $("#choice");
                $.each(my_json[1], function(key, val) {
                    // alert("key="+key+","+"val="+val);
                    choiceContainer.append('<div class="col-md-4"  name="'+key+'">'+key+':'+val+'</div>');
                });
            }
            //动态添加标签
            TimeVisitor();

        },
        //性别比例
        initGenderCharts: function () {
        if (!jQuery.plot) {
            return;
        }
        var data = [];
        GenderControls();
        function GenderControls() {
            //图标数据
            var d2 = [];
                d2.push([61,3]);     //产生随机数放到数组d2中
                d2.push([39,1]);     //产生随机数放到数组d2中


            var stack = 0,        //默认显示
                bars = true;

            function plotWithOptions() {

                $.plot($("#genderControls"),
                    [  {data: d2, label: "d2 Views"}], //导入数据，显示对应的数据名称
                    {

                        series: {
                            //设置如何绘图为柱状图时的相关属性
                            bars: {
                               show:true
                            }
                        },
                          bars: {
                            align: "left",
                            barWidth: 0.5,
                            horizontal: true,
                        },
                        xaxis: {
                            show: true,
                            min: 0,
                            max: 100,
                            tickFormatter: function (v) {
                                return v + "%";
                            }
                        },
                        yaxis: {
                            show: true,
                            ticks: [[0],[1,'女'],[2],[3,'男'],[4]],
                            tickSize: 0.5,

                        },
                        grid: {
                        hoverable: true
                    }

                    });
                //显示插入的html
                function showTooltip(x, y, contents) {
                    $('<div id="tooltip">' + contents + '</div>').css({
                        position: 'absolute',
                        display: 'none',
                        top: y + 5,
                        left: x + 15,
                        border: '1px solid #333',
                        padding: '4px',
                        color: '#fff',
                        'border-radius': '3px',
                        'background-color': '#333',
                        opacity: 0.80
                    }).appendTo("body").fadeIn(200);
                }

                //绑定鼠标移动事件
                var previousPoint = null;
                $("#genderControls").bind("plothover", function (event, pos, item) {

                    $("#x").text(pos.x.toFixed(2));
                    $("#y").text(pos.y.toFixed(2));

                    if (item) {

                        if (previousPoint != item.dataIndex) {
                            previousPoint = item.dataIndex;

                            $("#tooltip").remove();
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);
                            showTooltip(item.pageX, item.pageY, x+"%");
                        }
                    } else {
                        $("#tooltip").remove();
                        previousPoint = null;
                    }
                });
            }



            plotWithOptions();
        }





    },
        //年龄比例
        initAgeCharts: function () {
            if (!jQuery.plot) {
                return;
            }
            var data = [];
            GenderControls();
            function GenderControls() {
                //图标数据

                var d2 = [];
                for (var i = 0; i <= 7; i += 1)
                 d2.push([i, parseInt(Math.random() * 100)]);     //产生随机数放到数组d2中

                var stack = 0,        //默认显示
                    bars = true;

                function plotWithOptions() {

                    $.plot($("#AgeControls"),
                        [  {data: d2}], //导入数据，显示对应的数据名称
                        {
                            // legend:{
                            //     show: true,
                            //     labelFormatter:'年龄比例图',
                            // }
                            series: {
                                //设置如何绘图为柱状图时的相关属性
                                bars: {
                                    show:true
                                }
                            },
                            bars: {
                                align: "left",
                                barWidth: 0.5,
                            },
                            xaxis: {

                                ticks: [[1,'不足18岁'],[2,'19-25岁'],[3,'26-30岁'],[4,'31-35岁'],[5,'36-40岁'],[6,'41-50岁'],[7,'51-60岁'],[8,'60岁以上']],


                            },
                            yaxis: {

                                min: 0,
                                max: 100,
                                tickFormatter: function (v) {
                                    return v + "%";
                                }

                            },
                            grid: {
                                hoverable: true
                            }



                        });
                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#AgeControls").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);

                                showTooltip(item.pageX, item.pageY, y+"%");
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });
                }


                plotWithOptions();
            }





        },
        //职业比例
        initOccupationCharts:  function() {
            if (!jQuery.plot) {
                return;
            }
            var data = [];
            OccupationControl();
            function OccupationControl() {
                //图标数据

                var d2 = [];
                for (var i = 0; i <= 5; i += 1)
                    d2.push([i, parseFloat(Math.random() * 100)]);     //产生随机数放到数组d2中


                function plotWithOptions() {

                    $.plot($("#OccupationControls"),
                        [  {data: d2}], //导入数据，显示对应的数据名称
                        {

                            series: {
                                //设置如何绘图为柱状图时的相关属性
                                bars: {
                                    show:true
                                }
                            },
                            bars: {
                                align: "left",
                                barWidth: 0.5,
                            },
                            xaxis: {

                                ticks: [[1,'白领'],[2,'学生'],[3,'服务员'],[4,'医务人员'],[5,'公务员'],[0,'制造工人']],

                            },
                            yaxis: {

                                min: 0,
                                max: 100,
                                tickFormatter: function (v) {
                                    return v + "%";
                                }
                            },

                            grid: {
                                hoverable: true
                            }
                        });



                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#OccupationControls").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);

                                showTooltip(item.pageX, item.pageY, y+"%");
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });
                }

                plotWithOptions();
            }





        },
        //星座比例
        initConstellationCharts:  function() {
            var data = [];
            var series = Math.floor(Math.random() * 10) + 1;
            series = series < 5 ? 5 : series;

            for (var i = 0; i < series; i++) {
                data[i] = {
                    label: "Series" + (i + 1),
                    data: Math.floor(Math.random() * 100) + 1
                }
            }

            // GRAPH 1
            $.plot($("#ConstellationControls"), data, {
                series: {
                    pie: {
                        show: true
                    }
                },
                legend: {
                    show: false
                }
            });
        },
        //消费水平
        initConsumptionAbilityCharts:  function() {
            var data = [];
            var series = Math.floor(Math.random() * 6) + 1;  //生成0到11的随机数

            series = series < 5 ? 5 : series;                 //选择一个选择5到11的随机数

            for (var i = 0; i < series; i++) {                  //随机生成几个数据，有上面的随机数决定
                data[i] = {
                    label: "Series" + (i + 1),
                    data: Math.floor(Math.random() * 100) + 1
                }
            }

            // GRAPH 1
            $.plot($("#ConsumptionAbility"), data, {
                series: {
                    pie: {
                        show: true
                    }
                },
                legend: {
                    show: false
                }
            });
        },
        //消费频次
        initConsumptionFrequencyCharts:  function() {
            if (!jQuery.plot) {
                return;
            }
            var data = [];
            ConsumptionFrequencyControl();
            function ConsumptionFrequencyControl() {
                //图标数据

                var d2 = [];
                for (var i = 1; i <= 6; i += 1)
                    d2.push([i, parseFloat(Math.random() * 50)]);     //产生随机数放到数组d2中


                function plotWithOptions() {

                    $.plot($("#ConsumptionFrequency"), [  {data: d2}], //导入数据，显示对应的数据名称
                        {

                            series: {
                                //设置如何绘图为柱状图时的相关属性
                                bars: {
                                    show:true
                                }
                            },
                            bars: {
                                align: "center",
                                barWidth: 0.5,
                            },
                            xaxis: {

                                ticks: [[1,'未消费'],[2,'1次到3次'],[3,'3次到4次'],[4,'5次到7次'],[5,'8到13次'],[6,'多于13次']],

                            },
                            yaxis: {

                                min: 0,
                                max: 100,
                                tickFormatter: function (v) {
                                    return v + "%";
                                }
                            },

                            grid: {
                                hoverable: true
                            }
                        });

                    //显示插入的html
                    function showTooltip(x, y, contents) {
                        $('<div id="tooltip">' + contents + '</div>').css({
                            position: 'absolute',
                            display: 'none',
                            top: y + 5,
                            left: x + 15,
                            border: '1px solid #333',
                            padding: '4px',
                            color: '#fff',
                            'border-radius': '3px',
                            'background-color': '#333',
                            opacity: 0.80
                        }).appendTo("body").fadeIn(200);
                    }

                    //绑定鼠标移动事件
                    var previousPoint = null;
                    $("#ConsumptionFrequency").bind("plothover", function (event, pos, item) {

                        $("#x").text(pos.x.toFixed(2));
                        $("#y").text(pos.y.toFixed(2));

                        if (item) {

                            if (previousPoint != item.dataIndex) {
                                previousPoint = item.dataIndex;

                                $("#tooltip").remove();
                                var x = item.datapoint[0].toFixed(2),
                                    y = item.datapoint[1].toFixed(2);

                                showTooltip(item.pageX, item.pageY, y+"%");
                            }
                        } else {
                            $("#tooltip").remove();
                            previousPoint = null;
                        }
                    });
                }

                plotWithOptions();
            }





        },
        //上网时段
        initAccessInternetCharts: function () {
        if (!jQuery.plot) {
            return;
        }
        var data = [];
            AccessInternetControls();
        function AccessInternetControls() {
            //图标数据

            var d2 = [];
            for (var i = 0; i <= 23; i += 1)
                d2.push([i, parseInt(Math.random() * 50)]);     //产生随机数放到数组d2中

            var stack = 0,        //默认显示
                bars = true;

            function plotWithOptions() {

                $.plot($("#AccessInternet"),
                    [  {data: d2}], //导入数据，显示对应的数据名称
                    {
                        series: {
                            //设置如何绘图为柱状图时的相关属性
                            bars: {
                                show:true
                            }
                        },
                        bars: {
                            align: "left",
                            barWidth: 0.5,
                        },
                        xaxis: {
                            // mode:"time",
                            // min:0,
                            // max:24,
                            //
                            tickSize:1,
                            tickFormatter: function (v) {
                                return v + "h";
                            }

                        },
                        yaxis: {
                            axisLabelPadding: 3,
                            min: 0,
                            max: 100,
                            tickFormatter: function (v) {
                                return v + "%";
                            }

                        },
                        grid: {
                            hoverable: true
                        }

                    });
                //显示插入的html
                function showTooltip(x, y, contents) {
                    $('<div id="tooltip">' + contents + '</div>').css({
                        position: 'absolute',
                        display: 'none',
                        top: y + 5,
                        left: x + 15,
                        border: '1px solid #333',
                        padding: '4px',
                        color: '#fff',
                        'border-radius': '3px',
                        'background-color': '#333',
                        opacity: 0.80
                    }).appendTo("body").fadeIn(200);
                }

                //绑定鼠标移动事件
                var previousPoint = null;
                $("#AccessInternet").bind("plothover", function (event, pos, item) {

                    $("#x").text(pos.x.toFixed(2));
                    $("#y").text(pos.y.toFixed(2));

                    if (item) {

                        if (previousPoint != item.dataIndex) {
                            previousPoint = item.dataIndex;

                            $("#tooltip").remove();
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);

                            showTooltip(item.pageX, item.pageY, y+"%");
                        }
                    } else {
                        $("#tooltip").remove();
                        previousPoint = null;
                    }
                });
            }


            plotWithOptions();
        }

    },
        };

}();