package com.zjht.UserAnalysis.test.dao;

import com.zjht.UserAnalysis.test.dao.mapper.UserAnalysisMapper;
import com.zjht.UserAnalysis.test.entity.*;
import com.zjht.UserAnalysis.test.entity.Comsumption.AreaOrder;
import com.zjht.UserAnalysis.test.entity.Comsumption.GoodsSellCustomer;
import com.zjht.UserAnalysis.test.entity.Comsumption.UserBuyTimes;
import com.zjht.UserAnalysis.test.entity.Goods.GoodsSell;
import com.zjht.UserAnalysis.test.entity.Goods.KeyWord;
import com.zjht.UserAnalysis.test.entity.Goods.OrderCalc;
import com.zjht.UserAnalysis.test.entity.Online.OnlinePeriod;
import com.zjht.UserAnalysis.test.entity.Personas.AgeCalc;
import com.zjht.UserAnalysis.test.entity.Personas.SexCalc;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceBrower;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceOS;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceType;
import com.zjht.UserAnalysis.test.entity.UserAccerss.OriginCalc;
import com.zjht.UserAnalysis.test.entity.UserAccerss.VisitCalc;
import com.zjht.UserAnalysis.test.entity.UserAccerss.VisitPageCalc;
import com.zjht.UserAnalysis.test.entity.UserArea.AreaClient;
import com.zjht.UserAnalysis.test.entity.UserComprise.UserCompriseCalc;
import com.zjht.UserAnalysis.test.entity.UserComprise.UserCompriseCalcHour;
import com.zjht.UserAnalysis.test.entity.UserViscosity.HeightUserCalc;
import com.zjht.UserAnalysis.test.entity.UserViscosity.LightUserCalc;
import com.zjht.UserAnalysis.test.entity.UserViscosity.VitalityCalc;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.OriginCalcHour;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.VisitCalcHour;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.VisitPageCalcHour;
import org.smarabbit.massy.annotation.ExportService;

import java.util.List;

/**
 * Created by leaves chen<leaves615@gmail.com> on 16/3/30.
 *
 */
@ExportService(serviceTypes = {UserAnalysisDao.class, UserAnalysisWriteDao.class})
public class UserAnalysisDaoImpl implements UserAnalysisWriteDao {
    private UserAnalysisMapper userAnalysisMapper;

    public void setUserAnalysisMapper(UserAnalysisMapper userAnalysisMapper) {
        this.userAnalysisMapper = userAnalysisMapper;
    }

    @Override
    public int save(Test test) {
        return userAnalysisMapper.save(test);
    }
    @Override
    public Test findById(Long id) {
        return null;
    }

    //用户访问
    @Override
    public List<OriginCalc> findOriginCalc(String siteid,String source,String date) {
         return userAnalysisMapper.findOriginCalc(siteid, source, date);
    }
    @Override
    public List<VisitCalc> findVisitCalc(String siteid,String source,String date) {
        return userAnalysisMapper.findVisitCalc(siteid, source, date);
    }
    @Override
    public List<VisitPageCalc> findVisitPageCalc(String siteid,String source,String date) {
        return userAnalysisMapper.findVisitPageCalc(siteid, source, date);
    }

    @Override
    public List<String> findOriginCalcSiteid() {
        return userAnalysisMapper.findOriginCalcSiteid();
    }
    @Override
    public List<String> findVisitCalcSiteid() {
        return userAnalysisMapper.findVisitCalcSiteid();
    }
    @Override
    public List<String> findVisitPageCalcSiteid() {
        return userAnalysisMapper.findVisitPageCalcSiteid();
    }


    //用户访问分时
    @Override
    public List<OriginCalcHour> findOriginCalcHour(String siteid, String source, String date, String hour) {
        return userAnalysisMapper.findOriginCalcHour(siteid, source, date, hour);
    }
    @Override
    public List<VisitCalcHour> findVisitCalcHour(String siteid, String source, String date, String hour) {
        return userAnalysisMapper.findVisitCalcHour(siteid, source, date, hour);
    }
    @Override
    public List<VisitPageCalcHour> findVisitPageCalcHour(String siteid, String source, String date, String hour) {
        return userAnalysisMapper.findVisitPageCalcHour(siteid, source, date, hour);
    }
    @Override
    public List<String> findOriginCalcHourSiteid() {
        return userAnalysisMapper.findOriginCalcHourSiteid();
    }
    @Override
    public List<String> findVisitCalcHourSiteid() {
        return userAnalysisMapper.findVisitCalcHourSiteid();
    }
    @Override
    public List<String> findVisitPageCalcHourSiteid() {
        return userAnalysisMapper.findVisitPageCalcHourSiteid();
    }


    //用户组成
    @Override
    public List<UserCompriseCalc> findUserCompriseCalc(String startTime,String endTime,String source,String siteid) {
        return userAnalysisMapper.findUserCompriseCalc(startTime,endTime,source,siteid);
    }
    @Override
    public List<String> findUserCompriseCalcSource() {
        return userAnalysisMapper.findUserCompriseCalcSource();
    }


    //用户组成分时


    @Override
    public List<UserCompriseCalcHour> findUserCompriseCalcHour(String selectTime, String source, String siteid) {
        return userAnalysisMapper.findUserCompriseCalcHour(selectTime, source, siteid);
    }

    @Override
    public List<String> findUserCompriseCalcHourSource() {
        return userAnalysisMapper.findUserCompriseCalcHourSource();
    }

    //终端设备
    @Override
    public List<String> findDeviceBrowserSource() {
        return userAnalysisMapper.findDeviceBrowserSource();
    }
    @Override
    public List<String> findDeviceOSSource() {
        return userAnalysisMapper.findDeviceOSSource();
    }
    @Override
    public List<String> findDeviceTypeSource() {
        return userAnalysisMapper.findDeviceTypeSource();
    }
    @Override
    public List<DeviceBrower> findDeviceBrowser(String selectTime,String siteid,String source) {
        return userAnalysisMapper.findDeviceBrowser(selectTime,siteid,source);
    }
    @Override
    public List<DeviceOS> findDeviceOS(String selectTime,String siteid,String source) {
        return userAnalysisMapper.findDeviceOS(selectTime, siteid, source);
    }
    @Override
    public List<DeviceType> findDeviceType(String selectTime,String siteid,String source) {
        return userAnalysisMapper.findDeviceType(selectTime, siteid, source);
    }
   //地区客户
    @Override
    public List<AreaClient> findAreaClient(String selectTime,String siteid, String source) {
        return userAnalysisMapper.findAreaClient(selectTime,siteid, source);
    }
    @Override
    public List<String> findAreaClientSource() {
        return userAnalysisMapper.findAreaClientSource();
    }
    //商品分析
    @Override
    public List<String> findGoodsSellSource() {
        return userAnalysisMapper.findGoodsSellSource();
    }
    @Override
    public List<String> findKeyWordSource() {
        return userAnalysisMapper.findKeyWordSource();
    }
    @Override
    public List<String> findOrderCalcSource() {
        return userAnalysisMapper.findOrderCalcSource();
    }
    @Override
    public List<GoodsSell> findGoodsSell(String selectTime, String siteid, String source) {
        return userAnalysisMapper.findGoodsSell(selectTime, siteid, source);
    }
    @Override
    public List<KeyWord> findKeyWord(String selectTime, String siteid, String source) {
        return userAnalysisMapper.findKeyWord(selectTime, siteid, source);
    }
    @Override
    public List<OrderCalc> findOrderCalc(String startTime, String endTime, String siteid, String source) {
        return userAnalysisMapper.findOrderCalc(startTime, endTime, siteid, source);
    }
    //用户粘度
    @Override
    public List<VitalityCalc> findVitalityCalc(String startTime, String endTime, String siteid,String source) {
        return userAnalysisMapper.findVitalityCalc(startTime, endTime, siteid,source);
    }
    @Override
    public List<String> findVitalityCalcSource() {
        return userAnalysisMapper.findVitalityCalcSource();
    }
    //用户画像
    @Override
    public List<AgeCalc> findAgeCalc(String selectTime,String siteid, String source) {
        return userAnalysisMapper.findAgeCalc(selectTime,siteid, source);
    }
    @Override
    public List<String> findAgeCalcSource() {
        return userAnalysisMapper.findAgeCalcSource();
    }
    @Override
    public List<SexCalc> findSexCalc(String selectTime,String siteid, String source) {
        return userAnalysisMapper.findSexCalc(selectTime, siteid,source);
    }
    @Override
    public List<String> findSexCalcSource() {
        return userAnalysisMapper.findSexCalcSource();
    }
    //消费情况
    @Override
    public List<AreaOrder> findAreaOrder(String selectTime, String siteid,String source) {
        return userAnalysisMapper.findAreaOrder(selectTime, siteid,source);
    }
    @Override
    public List<String> findAreaOrderSource() {
        return userAnalysisMapper.findAreaOrderSource();
    }
    @Override
    public List<String> findAreaOrderArea(String source) {
        return userAnalysisMapper.findAreaOrderArea(source);
    }

    @Override
    public List<AreaOrder> findAreaOrderByAreaSource(String selectTime, String area, String siteid,String source) {
        return userAnalysisMapper.findAreaOrderByAreaSource(selectTime, area, siteid,source);
    }

    @Override
    public List<GoodsSellCustomer> findGoodsSellCustomer(String selectTime,String siteid, String source) {
        return userAnalysisMapper.findGoodsSellCustomer(selectTime, siteid,source);
    }
    @Override
    public List<String> findGoodsSellCustomerSource() {
        return userAnalysisMapper.findGoodsSellCustomerSource();
    }
    @Override
    public List<UserBuyTimes> findUserBuyTimes(String selectTime,String siteid, String source) {
        return userAnalysisMapper.findUserBuyTimes(selectTime,siteid, source);
    }
    @Override
    public List<String> findUserBuyTimesSource() {
        return userAnalysisMapper.findUserBuyTimesSource();
    }

    //上网时段

    @Override
    public List<OnlinePeriod> findOnlinePeriod(String selectTime, String siteid, String source) {
        return userAnalysisMapper.findOnlinePeriod(selectTime, siteid, source);
    }

    @Override
    public List<String> findOnlinePeriodSiteid() {
        return userAnalysisMapper.findOnlinePeriodSiteid();
    }


    @Override
    public List<HeightUserCalc> findHeightUserCalc(String startTime, String endTime, String siteid, String source) {
        return userAnalysisMapper.findHeightUserCalc(startTime, endTime, siteid, source);
    }

    @Override
    public List<String> findHeightUserCalcSiteid() {
        return userAnalysisMapper.findHeightUserCalcSiteid();
    }

    @Override
    public List<LightUserCalc> findLightUserCalc(String startTime, String endTime, String siteid, String source) {
        return userAnalysisMapper.findLightUserCalc(startTime, endTime, siteid, source);
    }

    @Override
    public List<String> findLightUserCalcSiteid() {
        return userAnalysisMapper.findLightUserCalcSiteid();
    }

    @Override
    public List<Site> findStie(int sitestatus) {
        return userAnalysisMapper.findStie(sitestatus);
    }
}
