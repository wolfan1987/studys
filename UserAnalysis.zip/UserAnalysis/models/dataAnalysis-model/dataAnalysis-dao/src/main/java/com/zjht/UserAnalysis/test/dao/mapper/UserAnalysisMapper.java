package com.zjht.UserAnalysis.test.dao.mapper;

import com.zjht.UserAnalysis.test.entity.*;
import com.zjht.UserAnalysis.test.entity.Comsumption.AreaOrder;
import com.zjht.UserAnalysis.test.entity.Comsumption.GoodsSellCustomer;
import com.zjht.UserAnalysis.test.entity.Comsumption.UserBuyTimes;
import com.zjht.UserAnalysis.test.entity.Goods.GoodsSell;
import com.zjht.UserAnalysis.test.entity.Goods.KeyWord;
import com.zjht.UserAnalysis.test.entity.Goods.OrderCalc;
import com.zjht.UserAnalysis.test.entity.Online.OnlinePeriod;
import com.zjht.UserAnalysis.test.entity.Personas.AgeCalc;
import com.zjht.UserAnalysis.test.entity.Personas.SexCalc;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceBrower;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceOS;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceType;
import com.zjht.UserAnalysis.test.entity.UserAccerss.OriginCalc;
import com.zjht.UserAnalysis.test.entity.UserAccerss.VisitCalc;
import com.zjht.UserAnalysis.test.entity.UserAccerss.VisitPageCalc;
import com.zjht.UserAnalysis.test.entity.UserArea.AreaClient;
import com.zjht.UserAnalysis.test.entity.UserComprise.UserCompriseCalc;
import com.zjht.UserAnalysis.test.entity.UserComprise.UserCompriseCalcHour;
import com.zjht.UserAnalysis.test.entity.UserViscosity.HeightUserCalc;
import com.zjht.UserAnalysis.test.entity.UserViscosity.LightUserCalc;
import com.zjht.UserAnalysis.test.entity.UserViscosity.VitalityCalc;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.OriginCalcHour;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.VisitCalcHour;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.VisitPageCalcHour;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by leaves chen<leaves615@gmail.com> on 16/3/30.
 *
 * @Author leaves chen<leaves615@gmail.com>
 */
public interface UserAnalysisMapper {

    int save(@Param("test") Test test);
    Test findById(@Param("id") Long id);





    //用户访问页面
    public   List<OriginCalc> findOriginCalc(@Param("siteid")String siteid,@Param("source")String source,@Param("date")String date); //获取核心指标数据
    public   List<VisitCalc> findVisitCalc(@Param("siteid")String siteid,@Param("source")String source,@Param("date")String date); //获取网站受访
    public   List<VisitPageCalc> findVisitPageCalc(@Param("siteid")String siteid,@Param("source")String source,@Param("date")String date);//获取网站来源

    public   List<String> findOriginCalcSiteid(); //获取核心指标数据
    public   List<String> findVisitCalcSiteid(); //获取网站受访
    public   List<String> findVisitPageCalcSiteid();//获取网站来源


    //用户访问来源分时

    public   List<OriginCalcHour> findOriginCalcHour(@Param("siteid")String siteid, @Param("source")String source, @Param("date")String date, @Param("hour")String hour); //获取核心指标数据
    public   List<VisitCalcHour> findVisitCalcHour(@Param("siteid")String siteid, @Param("source")String source, @Param("date")String date, @Param("hour")String hour); //获取网站受访
    public   List<VisitPageCalcHour> findVisitPageCalcHour(@Param("siteid")String siteid, @Param("source")String source, @Param("date")String date, @Param("hour")String hour);//获取网站来源

    public   List<String> findOriginCalcHourSiteid(); //获取核心指标数据
    public   List<String> findVisitCalcHourSiteid(); //获取网站受访
    public   List<String> findVisitPageCalcHourSiteid();//获取网站来源














    //用户组成
    List<UserComposition> findUserComposition();
    List<UserCompriseCalc> findUserCompriseCalc(@Param("startTime")String startTime,@Param("endTime")String endTime,@Param("source")String source,@Param("siteid")String siteid);
    List<String> findUserCompriseCalcSource(); //获取用户组成的来源


    //用户组成信息分时
    public List<UserCompriseCalcHour> findUserCompriseCalcHour(@Param("selectTime") String selectTime,@Param("source")String source, @Param("siteid") String siteid );  //获取用户组成信息
    public List<String> findUserCompriseCalcHourSource(); //获取用户组成的网站站点



    //终端设备
    public List<String> findDeviceBrowserSource();
    public List<String> findDeviceOSSource();
    public List<String> findDeviceTypeSource();
    public List<DeviceBrower> findDeviceBrowser(@Param("selectTime")String startTime,@Param("siteid")String siteid,@Param("source")String source);
    public List<DeviceOS> findDeviceOS(@Param("selectTime")String startTime,@Param("siteid")String siteid,@Param("source")String source);
    public List<DeviceType> findDeviceType(@Param("selectTime")String startTime,@Param("siteid")String siteid,@Param("source")String source);

    //地区客户
     List<AreaClient> findAreaClient(@Param("selectTime")String selectTime,@Param("siteid")String siteid,@Param("source") String source);
     List<String> findAreaClientSource();

     List<String> findGoodsSellSource();
     List<String> findKeyWordSource();
     List<String> findOrderCalcSource();
     List<GoodsSell> findGoodsSell(@Param("selectTime")String selectTime, @Param("siteid")String siteid, @Param("source")String source);
     List<KeyWord> findKeyWord(@Param("selectTime")String selectTime, @Param("siteid")String siteid, @Param("source")String source);
     List<OrderCalc> findOrderCalc(@Param("startTime")String startTime,@Param("endTime") String endTime,@Param("siteid") String siteid, @Param("source")String source);

    //用户活跃度
    public List<VitalityCalc> findVitalityCalc(@Param("startTime")String startTime,@Param("endTime")String endTime,@Param("siteid")String siteid,@Param("source")String source);
    public List<String> findVitalityCalcSource();

    //用户画像
     List<AgeCalc> findAgeCalc(@Param("selectTime")String selectTime, @Param("siteid")String siteid,@Param("source") String source);
     List<String> findAgeCalcSource();

     List<SexCalc> findSexCalc(@Param("selectTime")String selectTime, @Param("siteid")String siteid,@Param("source") String source);
     List<String> findSexCalcSource();
      //消费情况
      List<AreaOrder> findAreaOrder(@Param("selectTime")String selectTime,@Param("siteid") String siteid,@Param("source") String source);
      List<String> findAreaOrderSource();
      List<String> findAreaOrderArea(@Param("siteid")String siteid);
      List<AreaOrder> findAreaOrderByAreaSource(@Param("selectTime")String selectTime,@Param("area")String area,@Param("siteid") String siteid,@Param("source") String source);
        //商品消费
      List<GoodsSellCustomer> findGoodsSellCustomer(@Param("selectTime")String selectTime,@Param("siteid") String siteid,@Param("source") String source);
      List<String> findGoodsSellCustomerSource();
        //用户消费
      List<UserBuyTimes> findUserBuyTimes(@Param("selectTime")String selectTime,@Param("siteid") String siteid,@Param("source") String source);
      List<String> findUserBuyTimesSource();

    //上网时段
     List<OnlinePeriod> findOnlinePeriod(@Param("selectTime")String selectTime, @Param("siteid")String siteid, @Param("source")String source);
     List<String> findOnlinePeriodSiteid();

    //用户粘度
    public List<HeightUserCalc> findHeightUserCalc(@Param("startTime")String startTime,@Param("endTime")String endTime,@Param("siteid")String siteid,@Param("source")String source);
    public List<String> findHeightUserCalcSiteid();

    public List<LightUserCalc> findLightUserCalc(@Param("startTime")String startTime,@Param("endTime")String endTime,@Param("siteid")String siteid,@Param("source")String source);
    public List<String> findLightUserCalcSiteid();


     //站点id
     public List<Site> findStie(@Param("sitestatus")int sitestatus);
}
