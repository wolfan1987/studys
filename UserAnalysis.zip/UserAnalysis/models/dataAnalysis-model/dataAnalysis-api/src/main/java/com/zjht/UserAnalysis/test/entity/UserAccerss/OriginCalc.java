package com.zjht.UserAnalysis.test.entity.UserAccerss;

/**
 * Created by xiaojia on 2016/9/12.
 */
public class OriginCalc {
    private int id;
    private String siteid;
    private String source;
    private String calc_date;
    private String origin;
    private int originnum;
    public OriginCalc() {
    }

    public OriginCalc(int id, String siteid, String source, String calc_date, String origin, int originnum) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calc_date = calc_date;
        this.origin = origin;
        this.originnum = originnum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalc_date() {
        return calc_date;
    }

    public void setCalc_date(String calc_date) {
        this.calc_date = calc_date;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public int getOriginnum() {
        return originnum;
    }

    public void setOriginnum(int originnum) {
        this.originnum = originnum;
    }
}
