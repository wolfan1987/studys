package com.zjht.UserAnalysis.test.entity.UserAccerss;

/**
 * Created by xiaojia on 2016/9/12.
 */
public class VisitPageCalc {

    private int id;
    private String siteid;
    private String source;
    private String calc_date;
    private String url;
    private int urlnum;

    public VisitPageCalc() {
    }


    public VisitPageCalc(int id, String siteid, String source, String calc_date, String url, int urlnum) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calc_date = calc_date;
        this.url = url;
        this.urlnum = urlnum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalc_date() {
        return calc_date;
    }

    public void setCalc_date(String calc_date) {
        this.calc_date = calc_date;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getUrlnum() {
        return urlnum;
    }

    public void setUrlnum(int urlnum) {
        this.urlnum = urlnum;
    }
}
