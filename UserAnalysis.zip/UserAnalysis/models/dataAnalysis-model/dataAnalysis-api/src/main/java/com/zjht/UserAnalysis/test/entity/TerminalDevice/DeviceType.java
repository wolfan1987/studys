package com.zjht.UserAnalysis.test.entity.TerminalDevice;

/**
 * Created by xiaojia on 2016/9/20.
 */
public class DeviceType {
    private int id;
    private String source;
    private String siteid;
    private String caleDate;
    private String deviceType;
    private int total;

    public DeviceType() {
    }

    public DeviceType(int id, String source, String siteid, String caleDate, String deviceType, int total) {
        this.id = id;
        this.source = source;
        this.siteid = siteid;
        this.caleDate = caleDate;
        this.deviceType = deviceType;
        this.total = total;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCaleDate() {
        return caleDate;
    }

    public void setCaleDate(String caleDate) {
        this.caleDate = caleDate;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }
}
