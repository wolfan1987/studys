package com.zjht.UserAnalysis.test.entity.UserVisitHours;

/**
 * Created by xiaojia on 2016/9/12.
 */
public class VisitCalcHour {
    private int id;
    private String siteid;
    private String source;
    private String calc_date;
    private String calc_hour;
    private int  page_total;
    private int ip_total;
    private int vistor_total;
    private double user_viscosity;

    public VisitCalcHour() {
    }

    public VisitCalcHour(int id, String siteid, String source, String calc_date, String calc_hour, int page_total, int ip_total, int vistor_total, double user_viscosity) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calc_date = calc_date;
        this.calc_hour = calc_hour;
        this.page_total = page_total;
        this.ip_total = ip_total;
        this.vistor_total = vistor_total;
        this.user_viscosity = user_viscosity;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalc_date() {
        return calc_date;
    }

    public void setCalc_date(String calc_date) {
        this.calc_date = calc_date;
    }

    public int getPage_total() {
        return page_total;
    }

    public void setPage_total(int page_total) {
        this.page_total = page_total;
    }

    public int getIp_total() {
        return ip_total;
    }

    public void setIp_total(int ip_total) {
        this.ip_total = ip_total;
    }

    public int getVistor_total() {
        return vistor_total;
    }

    public void setVistor_total(int vistor_total) {
        this.vistor_total = vistor_total;
    }

    public double getUser_viscosity() {
        return user_viscosity;
    }

    public void setUser_viscosity(double user_viscosity) {
        this.user_viscosity = user_viscosity;
    }

    public String getCalc_hour() {
        return calc_hour;
    }

    public void setCalc_hour(String calc_hour) {
        this.calc_hour = calc_hour;
    }
}
