package com.zjht.UserAnalysis.test.entity.TerminalDevice;

/**
 * Created by xiaojia on 2016/9/20.
 */
public class DeviceBrower {
      private int id;
      private String source;
      private String siteid;
      private String caleDate;
      private String browser;
      private int total;

    public DeviceBrower() {
    }

    public DeviceBrower(int id, String source, String siteid, String caleDate, String browser, int total) {
        this.id = id;
        this.source = source;
        this.siteid = siteid;
        this.caleDate = caleDate;
        this.browser = browser;
        this.total = total;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCaleDate() {
        return caleDate;
    }

    public void setCaleDate(String caleDate) {
        this.caleDate = caleDate;
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }
}
