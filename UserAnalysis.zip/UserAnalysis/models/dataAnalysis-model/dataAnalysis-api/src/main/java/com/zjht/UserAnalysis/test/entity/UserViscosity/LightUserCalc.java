package com.zjht.UserAnalysis.test.entity.UserViscosity;

/**
 * Created by xiaojia on 2016/9/26.
 */
public class LightUserCalc {
    private int id;
    private String siteid;
    private String source;
    private String calc_date;
    private double  user_precent;
    private double user_index;
    private double page_precent;

    public LightUserCalc() {
    }

    public LightUserCalc(int id, String siteid, String source, String calc_date, double user_precent, double user_index, double page_precent) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calc_date = calc_date;
        this.user_precent = user_precent;
        this.user_index = user_index;
        this.page_precent = page_precent;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalc_date() {
        return calc_date;
    }

    public void setCalc_date(String calc_date) {
        this.calc_date = calc_date;
    }

    public double getUser_precent() {
        return user_precent;
    }

    public void setUser_precent(double user_precent) {
        this.user_precent = user_precent;
    }

    public double getUser_index() {
        return user_index;
    }

    public void setUser_index(double user_index) {
        this.user_index = user_index;
    }

    public double getPage_precent() {
        return page_precent;
    }

    public void setPage_precent(double page_precent) {
        this.page_precent = page_precent;
    }
}
