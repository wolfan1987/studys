package com.zjht.UserAnalysis.test.entity.Goods;

/**
 * Created by xiaojia on 2016/9/22.
 */
public class KeyWord {
    private int id;
    private String source;
    private String siteid;
    private String calcDate;
    private String keyword;
    private int total;

    public KeyWord() {
    }

    public KeyWord(int id, String source, String siteid, String calcDate, String keyword, int total) {
        this.id = id;
        this.source = source;
        this.siteid = siteid;
        this.calcDate = calcDate;
        this.keyword = keyword;
        this.total = total;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalcDate() {
        return calcDate;
    }

    public void setCalcDate(String calcDate) {
        this.calcDate = calcDate;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
