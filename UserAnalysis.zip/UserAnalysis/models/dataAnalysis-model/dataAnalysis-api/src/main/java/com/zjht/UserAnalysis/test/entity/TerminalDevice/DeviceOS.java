package com.zjht.UserAnalysis.test.entity.TerminalDevice;

/**
 * Created by xiaojia on 2016/9/20.
 */
public class DeviceOS {
    private int id;
    private String source;
    private String siteid;
    private String caleDate;
    private String os;
    private int total;

    public DeviceOS() {
    }

    public DeviceOS(int id, String source, String siteid, String caleDate, String os, int total) {
        this.id = id;
        this.source = source;
        this.siteid = siteid;
        this.caleDate = caleDate;
        this.os = os;
        this.total = total;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCaleDate() {
        return caleDate;
    }

    public void setCaleDate(String caleDate) {
        this.caleDate = caleDate;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }
}
