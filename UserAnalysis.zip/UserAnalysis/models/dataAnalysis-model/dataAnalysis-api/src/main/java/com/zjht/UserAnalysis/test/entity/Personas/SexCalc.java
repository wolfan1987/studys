package com.zjht.UserAnalysis.test.entity.Personas;

/**
 * Created by xiaojia on 2016/9/21.
 */
public class SexCalc {
    private int id;
    private String siteid;
    private String source;
    private String calcDate;
    private String sex;
    private int total;

    public SexCalc() {
    }

    public SexCalc(int id, String siteid, String source, String calcDate, String sex, int total) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calcDate = calcDate;
        this.sex = sex;
        this.total = total;
    }

    public SexCalc(int id, String source, String calcDate, String sex, int total) {
        this.id = id;
        this.source = source;
        this.calcDate = calcDate;
        this.sex = sex;
        this.total = total;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalcDate() {
        return calcDate;
    }

    public void setCalcDate(String calcDate) {
        this.calcDate = calcDate;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }


    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }
}
