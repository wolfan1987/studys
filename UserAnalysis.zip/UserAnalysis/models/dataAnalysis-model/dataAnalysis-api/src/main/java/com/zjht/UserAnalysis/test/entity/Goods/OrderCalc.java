package com.zjht.UserAnalysis.test.entity.Goods;

/**
 * Created by xiaojia on 2016/9/22.
 */
public class OrderCalc {
    private int id;
    private String siteid;
    private String source;
    private String calcDate;
    private int total;
    private int unpayTotal;
    private int payTotal;
    private double unpayPrecent;
    private double payPrecent;

    public OrderCalc() {
    }

    public OrderCalc(int id, String siteid, String source, String calcDate, int total, int unpayTotal, int payTotal, double unpayPrecent, double payPrecent) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calcDate = calcDate;
        this.total = total;
        this.unpayTotal = unpayTotal;
        this.payTotal = payTotal;
        this.unpayPrecent = unpayPrecent;
        this.payPrecent = payPrecent;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalcDate() {
        return calcDate;
    }

    public void setCalcDate(String calcDate) {
        this.calcDate = calcDate;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getUnpayTotal() {
        return unpayTotal;
    }

    public void setUnpayTotal(int unpayTotal) {
        this.unpayTotal = unpayTotal;
    }

    public int getPayTotal() {
        return payTotal;
    }

    public void setPayTotal(int payTotal) {
        this.payTotal = payTotal;
    }

    public double getUnpayPrecent() {
        return unpayPrecent;
    }

    public void setUnpayPrecent(double unpayPrecent) {
        this.unpayPrecent = unpayPrecent;
    }

    public double getPayPrecent() {
        return payPrecent;
    }

    public void setPayPrecent(double payPrecent) {
        this.payPrecent = payPrecent;
    }
}
