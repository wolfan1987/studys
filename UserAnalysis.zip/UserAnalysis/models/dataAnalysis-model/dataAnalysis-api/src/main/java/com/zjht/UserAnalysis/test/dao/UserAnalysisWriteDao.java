package com.zjht.UserAnalysis.test.dao;

import com.zjht.UserAnalysis.test.entity.Test;

/**
 * Created by leaves chen<leaves615@gmail.com> on 16/3/30.
 *
 * @Author leaves chen<leaves615@gmail.com>
 */
public interface UserAnalysisWriteDao extends UserAnalysisDao {
    int save(Test test);
}
