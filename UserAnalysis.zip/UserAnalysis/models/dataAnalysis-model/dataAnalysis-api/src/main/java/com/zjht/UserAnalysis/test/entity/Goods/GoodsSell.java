package com.zjht.UserAnalysis.test.entity.Goods;

/**
 * Created by xiaojia on 2016/9/22.
 */
public class GoodsSell {
    private int id;
    private String siteid;
    private String source;
    private String calcDate;
    private String ecitemid;
    private String ecitemname;
    private int total;

    public GoodsSell(int id, String siteid, String source, String calcDate, String ecitemid, String ecitemname, int total) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calcDate = calcDate;
        this.ecitemid = ecitemid;
        this.ecitemname = ecitemname;
        this.total = total;
    }

    public GoodsSell() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalcDate() {
        return calcDate;
    }

    public void setCalcDate(String calcDate) {
        this.calcDate = calcDate;
    }

    public String getEcitemid() {
        return ecitemid;
    }

    public void setEcitemid(String ecitemid) {
        this.ecitemid = ecitemid;
    }

    public String getEcitemname() {
        return ecitemname;
    }

    public void setEcitemname(String ecitemname) {
        this.ecitemname = ecitemname;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
