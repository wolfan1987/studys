package com.zjht.UserAnalysis.test.entity.UserComprise;

/**
 * Created by xiaojia on 2016/9/14.
 */
public class UserCompriseCalc {
    private int id;
    private String source;
    private String siteid;

    public UserCompriseCalc(int id, String source, String siteid, String calcDate, int registTotal, int newTotal, int oldTotal, int liveTotal, int deadTotal) {
        this.id = id;
        this.source = source;
        this.siteid = siteid;
        this.calcDate = calcDate;
        this.registTotal = registTotal;
        this.newTotal = newTotal;
        this.oldTotal = oldTotal;
        this.liveTotal = liveTotal;
        this.deadTotal = deadTotal;
    }

    private String calcDate;
    private int  registTotal;
    private int  newTotal;
    private int  oldTotal;
    private int  liveTotal;
    private int  deadTotal;

    public UserCompriseCalc() {
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalcDate() {
        return calcDate;
    }

    public void setCalcDate(String calcDate) {
        this.calcDate = calcDate;
    }

    public int getRegistTotal() {
        return registTotal;
    }

    public void setRegistTotal(int registTotal) {
        this.registTotal = registTotal;
    }

    public int getNewTotal() {
        return newTotal;
    }

    public void setNewTotal(int newTotal) {
        this.newTotal = newTotal;
    }

    public int getOldTotal() {
        return oldTotal;
    }

    public void setOldTotal(int oldTotal) {
        this.oldTotal = oldTotal;
    }

    public int getLiveTotal() {
        return liveTotal;
    }

    public void setLiveTotal(int liveTotal) {
        this.liveTotal = liveTotal;
    }

    public int getDeadTotal() {
        return deadTotal;
    }

    public void setDeadTotal(int deadTotal) {
        this.deadTotal = deadTotal;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }
}
