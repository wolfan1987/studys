package com.zjht.UserAnalysis.test.entity.Personas;

/**
 * Created by xiaojia on 2016/9/21.
 */
public class AgeCalc {
    private int id;
    private String siteid;
    private String source;
    private String calcDate;
    private int age;
    private int total;

    public AgeCalc() {
    }

    public AgeCalc(int id, String siteid, String source, String calcDate, int age, int total) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calcDate = calcDate;
        this.age = age;
        this.total = total;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalcDate() {
        return calcDate;
    }

    public void setCalcDate(String calcDate) {
        this.calcDate = calcDate;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }
}
