package com.zjht.UserAnalysis.test.entity;

/**
 * Created by xiaojia on 2016/7/25.
 */
public class UserSource {
    private int id;
    private String tcp;
    private String laifang;
    private String date;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public UserSource() {
    }

    public UserSource(String tcp, String laifang) {
        this.tcp = tcp;
        this.laifang = laifang;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTcp() {
        return tcp;
    }

    public void setTcp(String tcp) {
        this.tcp = tcp;
    }

    public String getLaifang() {
        return laifang;
    }

    public void setLaifang(String laifang) {
        this.laifang = laifang;
    }
}
