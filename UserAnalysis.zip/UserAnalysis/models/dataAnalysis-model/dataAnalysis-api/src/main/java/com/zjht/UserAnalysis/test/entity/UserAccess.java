package com.zjht.UserAnalysis.test.entity;

/**
 * Created by xiaojia on 2016/7/25.
 */
public class UserAccess {
    private int id;
    private String topshoufan;
    private String liukangcishu;
    private String date;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public UserAccess() {
    }

    public UserAccess(String topshoufan, String liukangcishu) {
        this.topshoufan = topshoufan;
        this.liukangcishu = liukangcishu;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTopshoufan() {
        return topshoufan;
    }

    public void setTopshoufan(String topshoufan) {
        this.topshoufan = topshoufan;
    }

    public String getLiukangcishu() {
        return liukangcishu;
    }

    public void setLiukangcishu(String liukangcishu) {
        this.liukangcishu = liukangcishu;
    }
}
