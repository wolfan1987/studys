package com.zjht.UserAnalysis.test.entity.UserVisitHours;

/**
 * Created by xiaojia on 2016/9/12.
 */
public class VisitPageCalcHour {

    private int id;
    private String siteid;
    private String source;
    private String calc_date;
    private String calc_hour;
    private String url;
    private int urlnum;

    public VisitPageCalcHour() {
    }


    public VisitPageCalcHour(int id, String siteid, String source, String calc_date, String calc_hour, String url, int urlnum) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calc_date = calc_date;
        this.calc_hour = calc_hour;
        this.url = url;
        this.urlnum = urlnum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalc_date() {
        return calc_date;
    }

    public void setCalc_date(String calc_date) {
        this.calc_date = calc_date;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getUrlnum() {
        return urlnum;
    }

    public void setUrlnum(int urlnum) {
        this.urlnum = urlnum;
    }

    public String getCalc_hour() {
        return calc_hour;
    }

    public void setCalc_hour(String calc_hour) {
        this.calc_hour = calc_hour;
    }

}
