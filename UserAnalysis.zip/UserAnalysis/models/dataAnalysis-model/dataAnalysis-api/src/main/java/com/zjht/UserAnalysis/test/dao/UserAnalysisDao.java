package com.zjht.UserAnalysis.test.dao;

import com.zjht.UserAnalysis.test.entity.*;
import com.zjht.UserAnalysis.test.entity.Comsumption.AreaOrder;
import com.zjht.UserAnalysis.test.entity.Comsumption.GoodsSellCustomer;
import com.zjht.UserAnalysis.test.entity.Comsumption.UserBuyTimes;
import com.zjht.UserAnalysis.test.entity.Goods.GoodsSell;
import com.zjht.UserAnalysis.test.entity.Goods.KeyWord;
import com.zjht.UserAnalysis.test.entity.Goods.OrderCalc;
import com.zjht.UserAnalysis.test.entity.Online.OnlinePeriod;
import com.zjht.UserAnalysis.test.entity.Personas.AgeCalc;
import com.zjht.UserAnalysis.test.entity.Personas.SexCalc;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceBrower;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceOS;
import com.zjht.UserAnalysis.test.entity.TerminalDevice.DeviceType;
import com.zjht.UserAnalysis.test.entity.UserAccerss.OriginCalc;
import com.zjht.UserAnalysis.test.entity.UserAccerss.VisitCalc;
import com.zjht.UserAnalysis.test.entity.UserAccerss.VisitPageCalc;
import com.zjht.UserAnalysis.test.entity.UserArea.AreaClient;
import com.zjht.UserAnalysis.test.entity.UserComprise.UserCompriseCalc;
import com.zjht.UserAnalysis.test.entity.UserComprise.UserCompriseCalcHour;
import com.zjht.UserAnalysis.test.entity.UserViscosity.HeightUserCalc;
import com.zjht.UserAnalysis.test.entity.UserViscosity.LightUserCalc;
import com.zjht.UserAnalysis.test.entity.UserViscosity.VitalityCalc;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.OriginCalcHour;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.VisitCalcHour;
import com.zjht.UserAnalysis.test.entity.UserVisitHours.VisitPageCalcHour;

import java.util.List;

/**
 * Created by leaves chen<leaves615@gmail.com> on 16/3/30.
 *
 */

public interface UserAnalysisDao {

    public  Test findById(Long id);


    //用户访问来源
    public   List<OriginCalc> findOriginCalc(String siteid,String source,String date); //获取核心指标数据
    public   List<VisitCalc> findVisitCalc(String siteid,String source,String date); //获取网站受访
    public   List<VisitPageCalc> findVisitPageCalc(String siteid,String source,String date);//获取网站来源
    public   List<String> findOriginCalcSiteid(); //获取核心指标数据
    public   List<String> findVisitCalcSiteid(); //获取网站受访
    public   List<String> findVisitPageCalcSiteid();//获取网站来源




    //用户访问来源分时
    public   List<OriginCalcHour> findOriginCalcHour(String siteid, String source, String date, String hour); //获取核心指标数据
    public   List<VisitCalcHour> findVisitCalcHour(String siteid, String source, String date, String hour); //获取网站受访
    public   List<VisitPageCalcHour> findVisitPageCalcHour(String siteid, String source, String date, String hour);//获取网站来源
    public   List<String> findOriginCalcHourSiteid(); //获取核心指标数据
    public   List<String> findVisitCalcHourSiteid(); //获取网站受访
    public   List<String> findVisitPageCalcHourSiteid();//获取网站来源




    //用户组成信息

    public List<UserCompriseCalc> findUserCompriseCalc(String startTime,String endTime,String source,String siteid);  //获取用户组成信息
    public List<String> findUserCompriseCalcSource(); //获取用户组成的网站站点




    //用户组成信息分时
    public List<UserCompriseCalcHour> findUserCompriseCalcHour(String selectTime, String source, String siteid  );  //获取用户组成信息
    public List<String> findUserCompriseCalcHourSource(); //获取用户组成的网站站点




    //终端设备
    public List<String> findDeviceBrowserSource();
    public List<String> findDeviceOSSource();
    public List<String> findDeviceTypeSource();
    public List<DeviceBrower> findDeviceBrowser(String selectTime,String siteid,String source);
    public List<DeviceOS> findDeviceOS(String selectTime,String siteid,String source);
    public List<DeviceType> findDeviceType(String selectTime,String siteid,String source);

     //地区客户
     public List<AreaClient> findAreaClient(String selectTime,String siteid,String source);
     public List<String> findAreaClientSource();

    //商品分析
    public List<String> findGoodsSellSource();
    public List<String> findKeyWordSource();
    public List<String> findOrderCalcSource();
    public List<GoodsSell> findGoodsSell(String selectTime, String siteid, String source);
    public List<KeyWord> findKeyWord(String selectTime, String siteid, String source);
    public List<OrderCalc> findOrderCalc(String startTime, String endTime,String siteid, String source);


    //用户活跃度
    public List<VitalityCalc> findVitalityCalc(String startTime,String endTime,String siteid,String source);
    public List<String> findVitalityCalcSource();
    
    //用户画像
    public List<AgeCalc> findAgeCalc(String selectTime,String siteid, String source);
    public List<String> findAgeCalcSource();
    public List<SexCalc> findSexCalc(String selectTime,String siteid, String source);
    public List<String> findSexCalcSource();
    
    //消费情况
      //地区订单
    public List<AreaOrder> findAreaOrder(String selectTime,String siteid ,String source);
    public List<String> findAreaOrderSource();
    public List<String> findAreaOrderArea(String source);
    public List<AreaOrder> findAreaOrderByAreaSource(String selectTime,String area, String siteid,String source);
        //商品消费
    public List<GoodsSellCustomer> findGoodsSellCustomer(String selectTime, String siteid,String source);
    public List<String> findGoodsSellCustomerSource();
        //用户消费
    public List<UserBuyTimes> findUserBuyTimes(String selectTime,String siteid, String source);
    public List<String> findUserBuyTimesSource();

    //上网时段
    public List<OnlinePeriod> findOnlinePeriod(String selectTime, String siteid,String source);
    public List<String> findOnlinePeriodSiteid();

    //用户粘度
    public List<HeightUserCalc> findHeightUserCalc(String startTime, String endTime, String siteid, String source);
    public List<String> findHeightUserCalcSiteid();

    public List<LightUserCalc> findLightUserCalc(String startTime, String endTime, String siteid, String source);
    public List<String> findLightUserCalcSiteid();

    //站点id
    public List<Site> findStie(int sitestatus);



}
