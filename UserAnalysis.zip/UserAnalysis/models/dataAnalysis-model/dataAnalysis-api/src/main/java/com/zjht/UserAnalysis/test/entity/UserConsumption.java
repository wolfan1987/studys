package com.zjht.UserAnalysis.test.entity;

/**
 * Created by xiaojia on 2016/8/16.
 */
public class UserConsumption {

     private int id ;
     private String username;
     private String time;
     private int number;


    public UserConsumption() {
    }

    public UserConsumption(String username, String time, int number) {
        this.username = username;
        this.time = time;
        this.number = number;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
