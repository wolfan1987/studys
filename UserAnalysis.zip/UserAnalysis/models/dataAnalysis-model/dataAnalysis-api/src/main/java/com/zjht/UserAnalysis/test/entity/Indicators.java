package com.zjht.UserAnalysis.test.entity;

/**
 * Created by xiaojia on 2016/7/25.
 */
public class Indicators {
    private int id;
    private String liulang;
    private String zidingyi;
    private String fangke;
    private String xinfangke;
    private String ip;
    private String date;

    public Indicators() {
    }

    public Indicators(String liulang, String zidingyi, String fangke, String xinfangke, String ip) {
        this.liulang = liulang;
        this.zidingyi = zidingyi;
        this.fangke = fangke;
        this.xinfangke = xinfangke;
        this.ip = ip;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLiulang() {
        return liulang;
    }

    public void setLiulang(String liulang) {
        this.liulang = liulang;
    }

    public String getZidingyi() {
        return zidingyi;
    }

    public void setZidingyi(String zidingyi) {
        this.zidingyi = zidingyi;
    }

    public String getFangke() {
        return fangke;
    }

    public void setFangke(String fangke) {
        this.fangke = fangke;
    }

    public String getXinfangke() {
        return xinfangke;
    }

    public void setXinfangke(String xinfangke) {
        this.xinfangke = xinfangke;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
