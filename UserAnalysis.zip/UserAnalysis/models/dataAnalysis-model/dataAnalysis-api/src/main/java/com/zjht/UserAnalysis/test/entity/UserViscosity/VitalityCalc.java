package com.zjht.UserAnalysis.test.entity.UserViscosity;

/**
 * Created by xiaojia on 2016/9/21.
 */
public class VitalityCalc {
    private int id;
    private String siteid;
    private String source;
    private String calaDate;
    private int hour;
    private String timearea;
    private int pv;
    private int uv;
    private int ip;

    public VitalityCalc() {
    }

    public VitalityCalc(int id, String siteid, String source, String calaDate, int hour, String timearea, int pv, int uv, int ip) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calaDate = calaDate;
        this.hour = hour;
        this.timearea = timearea;
        this.pv = pv;
        this.uv = uv;
        this.ip = ip;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalaDate() {
        return calaDate;
    }

    public void setCalaDate(String calaDate) {
        this.calaDate = calaDate;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public String getTimearea() {
        return timearea;
    }

    public void setTimearea(String timearea) {
        this.timearea = timearea;
    }

    public int getPv() {
        return pv;
    }

    public void setPv(int pv) {
        this.pv = pv;
    }

    public int getUv() {
        return uv;
    }

    public void setUv(int uv) {
        this.uv = uv;
    }

    public int getIp() {
        return ip;
    }

    public void setIp(int ip) {
        this.ip = ip;
    }
}
