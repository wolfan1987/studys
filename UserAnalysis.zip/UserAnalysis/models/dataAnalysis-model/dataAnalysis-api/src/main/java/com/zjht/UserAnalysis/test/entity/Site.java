package com.zjht.UserAnalysis.test.entity;

/**
 * Created by xiaojia on 2016/10/13.
 */
public class Site {
    private int id;
    private String siteid;
    private String siteurl;
    private String sitename;
    private int sitestatus;
    private String createdatime;

    public Site() {
    }

    public Site(int id, String siteid, String siteurl, String sitename, int sitestatus, String createdatime) {
        this.id = id;
        this.siteid = siteid;
        this.siteurl = siteurl;
        this.sitename = sitename;
        this.sitestatus = sitestatus;
        this.createdatime = createdatime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSiteurl() {
        return siteurl;
    }

    public void setSiteurl(String siteurl) {
        this.siteurl = siteurl;
    }

    public String getSitename() {
        return sitename;
    }

    public void setSitename(String sitename) {
        this.sitename = sitename;
    }

    public int getSitestatus() {
        return sitestatus;
    }

    public void setSitestatus(int sitestatus) {
        this.sitestatus = sitestatus;
    }

    public String getCreatedatime() {
        return createdatime;
    }

    public void setCreatedatime(String createdatime) {
        this.createdatime = createdatime;
    }
}
