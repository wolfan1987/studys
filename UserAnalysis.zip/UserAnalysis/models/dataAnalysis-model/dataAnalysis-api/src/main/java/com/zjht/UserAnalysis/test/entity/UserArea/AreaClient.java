package com.zjht.UserAnalysis.test.entity.UserArea;

/**
 * Created by xiaojia on 2016/9/21.
 */
public class AreaClient {
    private int id;
    private String siteid;
    private String source;
    private String calcDate;
    private String area;
    private int total;

    public AreaClient(int id, String siteid, String source, String calcDate, String area, int total) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calcDate = calcDate;
        this.area = area;
        this.total = total;
    }

    public AreaClient() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalcDate() {
        return calcDate;
    }

    public void setCalcDate(String calcDate) {
        this.calcDate = calcDate;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }
}
