package com.zjht.UserAnalysis.test.entity.Online;

/**
 * Created by xiaojia on 2016/9/23.
 */
public class OnlinePeriod {
    private int id;
    private String siteid;
    private String source;
    private String calcDate;
    private int hours;
    private String  timearea;
    private int total;

    public OnlinePeriod() {
    }

    public OnlinePeriod(int id, String siteid, String source, String calcDate, int hours, String timearea, int total) {
        this.id = id;
        this.siteid = siteid;
        this.source = source;
        this.calcDate = calcDate;
        this.hours = hours;
        this.timearea = timearea;
        this.total = total;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSiteid() {
        return siteid;
    }

    public void setSiteid(String siteid) {
        this.siteid = siteid;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCalcDate() {
        return calcDate;
    }

    public void setCalcDate(String calcDate) {
        this.calcDate = calcDate;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public String getTimearea() {
        return timearea;
    }

    public void setTimearea(String timearea) {
        this.timearea = timearea;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
