package com.zjht.UserAnalysis.test.entity;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by xiaojia on 2016/8/16.
 */
public class UserComposition {

     private int id;
     private Long cTime;
     private int user1;
     private int user2;
     private int user3;
     private int user4;
     private int user5;


    public UserComposition() {
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Long getCTime() {
        return cTime;
    }

    public void setCTime(Long cTime) {
        this.cTime = cTime;
    }

    public int getUser1() {
        return user1;
    }

    public void setUser1(int user1) {
        this.user1 = user1;
    }

    public int getUser2() {
        return user2;
    }

    public void setUser2(int user2) {
        this.user2 = user2;
    }

    public int getUser3() {
        return user3;
    }

    public void setUser3(int user3) {
        this.user3 = user3;
    }

    public int getUser4() {
        return user4;
    }

    public void setUser4(int user4) {
        this.user4 = user4;
    }

    public int getUser5() {
        return user5;
    }

    public void setUser5(int user5) {
        this.user5 = user5;
    }

    public UserComposition(int id, Long cTime, int user1, int user2, int user3, int user4, int user5) {
        this.id = id;
        this.cTime = cTime;
        this.user1 = user1;
        this.user2 = user2;
        this.user3 = user3;
        this.user4 = user4;
        this.user5 = user5;
    }
}
