/**
 * 
 */
package com.zjht.web.commons.template;

import org.smarabbit.massy.web.menu.SimpleMenu;

/**
 * @author huangkaihui
 *
 */
public class UserMenu extends SimpleMenu {

	/**
	 * 
	 */
	public UserMenu() {
		this.setSuperiorName(UserMenuGroup.NAME);
	}

}
