package test.run;

import myservice.MyService;

public class Run {

	public static void main(String[] args) {
		MyService service = new MyService();
		service.testMethod();

	}

}
