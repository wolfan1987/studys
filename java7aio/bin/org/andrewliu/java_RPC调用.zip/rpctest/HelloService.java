package org.andrewliu.rpctest;
/**
 * @Author AndrewLiu (liudaan@chinaexpresscard.com)
 * @Description:
 * @Date: Created in 2018/6/8 15:37
 * @Modifyed By:
 * @Other: A Lucky Man
 */
public interface HelloService {
    String hello(String name);
}
